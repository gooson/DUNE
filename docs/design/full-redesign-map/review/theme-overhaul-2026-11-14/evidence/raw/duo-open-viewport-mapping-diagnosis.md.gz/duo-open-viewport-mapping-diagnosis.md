# Open Duo physical direction and app viewport — read-only diagnosis

No source/runtime/build/test/LLDB/device actions performed. Existing retained-helper lifetime fix is proven by parent receipts and remains unchanged. This report concerns the distinct UI width assertion failure.

## Finding: test harness conflates physical direction with inner display orientation

Strong direct evidence supports a coordinate-mapping error in the new Open preflight/checkpoint, not an app rotation lock:

1. Current SDK27.2 run `duo-theme-open-DesertWarm-OceanCool-ForestGreen-SakuraCalm-20261114T130704Z`: official physical landscapeLeft is verified; `002-hierarchy.txt:4` reports actual Window669x951; parent PNG evidence also portrait. This matches a portrait inner UI at that physical pose.
2. Pinned serve-sim source at c60d583... `.agents/skills/serve-sim-duo-verification/scripts/verify-duo-rotation.ts` explicitly tests inner counter-rotation. It maps view `landscape_right` to CoreDevice physical `landscapeLeft`, then maps INNER `landscape_right` to UI `portrait`. Physical portrait maps inner UI `landscape_left`. This is explicit upstream expected behavior, not enum-name guessing.
3. Repository actual test evidence `docs/reviews/2026-10-06-duo-cli-fold-validation.md:97`: inner physical portrait→landscapeLeft→portrait produced app viewport951x669→669x951→951x669. Existing actual readback and native results establish that mapping.
4. Same SDK27.2 prior b05 evidence: `.codex-checks/b05/duo-open-host/orientation-after.json` physical portrait/nonFlat portrait; `009-hierarchy.txt:4` Window951x669. This is an older app and different owned device, so not current pass evidence, but supports SDK27.2 retaining the mapping.
5. October22 Life evidence `docs/design/full-redesign-map/review/life-hero-narrative-2026-10-22/README.md:31` explicitly specifies Open landscape951x669. Its retained display-state JSON reports physical landscapeRight and inner rot90; this differs from the clean SDK27.2 b05 physical-portrait evidence. Therefore do not assert one universal mapping solely from the October22 receipt. The first-fold report's nativeSize2007x2853 is panel inventory, not proof of portrait app orientation; do not confuse those values.

The current harness `run-duo-theme-batch.py:139,185` selects physical landscapeLeft for Open, while `UITestBaseCase.swift:187–198` sends ORIENT:landscapeLeft and requires width>height. Those requirements contradict the documented inner-panel mapping. The helper's preceding `XCUIDevice.shared.orientation=.landscapeLeft` introduces a second orientation mechanism, but its final host checkpoint reliably sets physicalLeft; merely reversing their order would obscure that mismatch.

## Narrow source inspection

Repository search found no application override of supportedInterfaceOrientations, shouldAutorotate, requestGeometryUpdate, preferredInterfaceOrientationForPresentation, or UIApplicationDelegateAdaptor. AppWindowSceneReader only registers the attached scene; AppWindowRouter handles scene open/close, not geometry. PostureCaptureService's orientationLock is an NSLock protecting camera state and is unrelated to UIKit orientation support. UIHostingController instances are offscreen share rendering.

project.yml supplies iPhone portrait+left+right and iPad all four orientation lists. Missing base UISupportedInterfaceOrientations alone is not evidence of an effective portrait-only mask. Do not change plist or requestGeometryUpdate/appResize based on this inspection: the observed viewport already matches the documented chosen physical pose. Effective runtime mask has not been interrogated and is not claimed proven.

## Minimal material remediation proposal (not applied)

Keep the design requirement exactly Open landscape951x669, plus fresh native PNG2853x2007.

- In ignored `run-duo-theme-batch.py`, set expected/commanded physical direction to `portrait` for BOTH closed and open. Hinge/active-display still distinguishes closed versus open. Preserve exact physical readback validation. Do not change driver enum mapping: existing portrait→1 is correct.
- In `UITestBaseCase.reassertDuoOpenLandscapeIfNeeded()`, retain current host-audit/FOLD/951pt guards, but REMOVE local `XCUIDevice.shared.orientation=.landscapeLeft` and change the checkpoint to `ORIENT:portrait theme root`. Comment that this denotes physical Duo portrait, which yields inner app landscape. Preserve width>height and preferably exact tolerant951x669 checks.
- The same incorrect two-line sequence is duplicated in `ThemeMatrixUITests.testDesertTodayToolbarFitsAtBothAppearances()`; route that guarded path through the corrected existing helper or apply the same host-only physical portrait checkpoint. Do not alter normal iPhone/iPad orientation behavior.
- `UITestBaseCase.setUpWithError()` has an opt-in DUNE_VISUAL_AUDIT_ORIENTATION=landscapeLeft branch. Current batch does not set this variable and repository xctestplans have no matching entry; confirm inherited env is absent for the retry. Do not introduce another forced orientation there.
- Keep retained helper lifetime+official readback and after-cleanup checks. No app source/plist changes, no new orientation API, no relaxed viewport test, no converted/rotated PNGs.

Suggested one minimal cause-specific UI recheck: `DUNEUITests/ThemeMatrixUITests/testDesertWarmMatrix` only, under the existing owned Duo lock and bounded runner after the helper/runner delta is reviewed. It exercises corrected root reassertion across both Light/Dark relaunches and captures all4 roots in each. The full4-method batch should not be the diagnostic retry. Confirm exact selector exists before executing (method is in ThemeMatrixUITests).

Pass evidence must combine physical portrait/nonFlat portrait and lock=false; LCD-1 active/activeOn with LCD inactive; fresh actual AUT951x669; native2853x2007; expected4-tab roots across both appearances. These are distinct observations. A successful physical getter alone is insufficient. If the corrected target still leaves669x951, stop with raw evidence and investigate actual scene/interface mask or geometry as a new unresolved condition; do not run appResize/geometry API alternatives in that same attempt.

Confidence: high that current physicalLeft + required landscape is inconsistent with source and prior actual mapping. Current app/source recheck remains unperformed. Closed evidence remains scoped valid; current Open4 failures remain failures and cannot be replaced by old native images.
