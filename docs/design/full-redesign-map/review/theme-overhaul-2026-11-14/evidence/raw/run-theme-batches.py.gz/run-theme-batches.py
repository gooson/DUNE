import argparse
import json
import os
import re
from pathlib import Path
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument("device")
p.add_argument("udid")
p.add_argument("--roots-only", action="store_true")
p.add_argument("--include-lilies", action="store_true")
p.add_argument("--themes", nargs="+")
p.add_argument("--suffix", default="")
a = p.parse_args()
root = Path(__file__).resolve().parents[2]
os.chdir(root)
source = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
themes = [("desert", "DesertWarm"), ("ocean", "OceanCool"), ("forest", "ForestGreen"),
          ("sakura", "SakuraCalm"), ("arctic", "ArcticDawn"), ("solar", "SolarPop"),
          ("contour", "ContourAtlas")]
if a.include_lilies:
    themes.append(("water-lilies", "WaterLilies"))
if a.themes:
    themes = [t for t in themes if t[0] in a.themes]
results = []
for label, method in themes:
    if subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip() != source:
        raise SystemExit("Source changed; stop before another batch")
    if subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=normal"], text=True).strip():
        raise SystemExit("Tracked source/output changed; inspect before another batch")
    name = f"theme-{a.device}-{label}{a.suffix}"
    log = f".codex-checks/theme-overhaul/{a.device}-{label}{a.suffix}.log"
    selectors = [f"DUNEUITests/ThemeMatrixUITests/test{method}Matrix"]
    if not a.roots_only:
        selectors.append(f"DUNEUITests/ThemeFlowMatrixUITests/test{method}Flows")
        maximum = "testDesertFourTabHeroesAtMaximumAccessibilityTextSize" if label == "desert" else f"test{method}MaximumAXRoots"
        selectors.append(f"DUNEUITests/ThemeMatrixUITests/{maximum}")
    command = ["python3", "scripts/codex-pipeline.py", "run", name, "--context",
               f"xcode27B52-ios27.2-{a.udid}-DesignCapture-seeded", "--scope", "all",
               "--content-only", "--", "scripts/test-ui.sh", "--no-regen",
               "--simulator-udid", a.udid, "--test-plan", "DUNEUITests-DesignCapture"]
    for selector in selectors:
        command += ["--only-testing", selector]
    command += ["--log-file", log]
    env = dict(os.environ, DUNE_UI_TEST_WALL_TIMEOUT="1200", DAILVE_UI_TEST_DERIVED_DATA_DIR=".deriveddata/unit-tests")
    print(f"Starting {name}: {len(selectors)} exact selectors, source {source[:9]}", flush=True)
    started = time.time()
    code = subprocess.call(command, env=env)
    results.append(dict(name=name, source=source, udid=a.udid, selectors=selectors, log=log,
                        exit_code=code, started=started, ended=time.time()))
    Path(f".codex-checks/theme-overhaul/{a.device}{a.suffix}-batches.json").write_text(json.dumps(results, indent=2)+"\n")
    matches = re.findall(r"^\s*(/.*\.xcresult)\s*$", Path(log).read_text(), re.M)
    if matches and Path(matches[-1]).exists():
        output = Path(".codex-checks/theme-overhaul/exports") / name
        with output.with_suffix(".txt").open("w") as export_log:
            exported = subprocess.run(["xcrun", "xcresulttool", "export", "attachments", "--path", matches[-1], "--output-path", str(output)], stdout=export_log, stderr=subprocess.STDOUT)
        if exported.returncode or not (output / "manifest.json").exists():
            raise SystemExit("Attachment preservation failed; stop before retention can remove another bundle")
        print(f"Preserved attachments: {output}", flush=True)
    else:
        raise SystemExit("Result bundle absent; stop before another batch")
    if code:
        raise SystemExit(code)
print(f"Completed {len(results)} {a.device} batches", flush=True)
