# App quality gate preflight — 2026-11-14

Scope: `origin/main` merge base `96d1a60e5` to `2c8b55481` (59 files), plus the current clean worktree. Read-only review of production theme scene, motion, hero contrast/date layout, color assets, affected UI tests, and receipts. This is not a final release approval: Duo and Watch evidence was pending when this preflight was written.

## Verdict

**Pending targeted runtime evidence.** The test-contract P2 below was resolved at `861865174`. No new P1 production-source finding identified in this preflight. Previous data P2 was resolved in `75599`; iPad receipt reports 10/10 selectors passed.

## Findings

### P2 — VoiceOver selector had an implicit host precondition (resolved at `861865174`)

At `2c8b55481`, `DUNEUITests/Visual/WaterLiliesThemeTests.swift:105-109` unconditionally asserted `UIAccessibility.isVoiceOverRunning`. The host-controlled enabled run passed 1/1, but ordinary UI runs would fail on a disabled simulator. The `2c8b55481..861865174` diff changes only this method's signature to `throws` and replaces the assertion with a guard that throws `XCTSkip` when the actual UIKit preference is false. The enabled body remains unchanged. The host wrapper still preflights native VoiceOver on and requires a positive executed/pass receipt, so an unexpected skip cannot satisfy that dedicated gate. This resolves the ordinary-suite false failure without claiming a fresh enabled run at this revision. Existing 1/1 evidence validates root/detail/return labels and route, not speech or complete reading order.

### P3 — Native Widget gallery remains unverified (test-only remediation removed)

The native gallery attempts in `phone-widget-retry.log.result.json` and `phone-widget-home-precondition.log.result.json` stopped at `Edit Home Screen action unavailable`, before WidgetKit rendered a family. At `861865174`, `DUNEUITests/Full/WatchWorkoutLiveActivityUITests.swift` matches `origin/main` exactly; the failed 39-line prototype is preserved at `.codex-checks/theme-overhaul/widget-unverified-prototype.patch`. Native widget rendering remains an explicitly unverified gap, not a passed route or an app-source theme regression. The original Desert widget test still depends on the system menu.

### Scope judgment — shared asset packaging is wider than changed consumers

The 30 changed Forest/Ocean `.colorset` values live in the shared catalog packaged for multiple targets. The changed names feed iOS theme color lookup, backgrounds and score/weather visuals (`ForestWaveBackground`, `AppTheme+View`, themed asset resolution). `DUNEWidget/DesignSystem.swift` uses only unchanged `ForestAccent`/`OceanAccent` for these themes and fixed generic widget colors otherwise. `DUNEVision/App/VisionThemePalette.swift` likewise selects only unchanged accent names. Watch `DesignSystem.swift` uses its own generic named colors; no changed Forest/Ocean names are referenced in Watch Swift sources. Thus the changed asset values do not establish a direct Widget/Watch/Vision rendering consumer. Compilation/package presence is a separate concern; target-specific runtime success should not be claimed from iPhone evidence.

## Evidence reviewed and remaining gate

- `AppThemeTests` 12 relevant unit cases, including eight themes × light/dark contrast, were reported passed by parent. Production code after `a5749e105` is unchanged; later changes concern inventory freshness and UI-only helpers. The trend line now uses `ScoreHeroPalette.trendLine`, with timestamp using `muted`, and `HourlySparklineView` can wrap long date ranges. The contrast test checks 3:1 for the trace and 4.5:1 for the small caption against the palette surface. Real render inspection remains useful for layout and texture.
- Phone roots/flows/MAX: parent reported current 64-root PNG and AX review with no P1/P2; native Reduce Motion, resume, persistence, locales, VoiceOver, and high contrast are separately scoped and passed. High contrast receipt shows 1/1. The VoiceOver receipt shows 1/1 under verified enabled native preference; setting restored afterward. No general full-suite claim.
- iPad `ipad-native.log.result.json`: 10 requested, 10 executed, 10 passed at `2c8b55481`.
- Duo Closed A native UI receipt passed 4/4; its first wrapper failed on an SDK `Window(Main)` regex. The corrected metadata-only validator reused saved PNG/AX and positive UI receipt, reporting 32 canonical captures and 65 paired checkpoints. The prior wrapper failure remains recorded; no full UI rerun is claimed. Duo Closed B, other Duo/Watch evidence and final design-map freshness remained pending at this update. Final gate must inspect their receipts and actual captures, then preserve any unavailable Widget/Vision runtime scope explicitly. Local full regression is not required by `.codex/skill-compat.md` for this change-based gate.

This review did not edit source, launch tests, or manipulate simulators.
