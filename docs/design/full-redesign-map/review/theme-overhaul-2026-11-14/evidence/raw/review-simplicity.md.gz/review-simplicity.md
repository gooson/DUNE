### [P3] Use the existing motion environment for Water Lilies
- **File**: `DUNE/Presentation/Shared/Components/WaterLiliesBackground.swift:44`
- **Category**: readability
- **Issue**: `AmbientScenePlayback` already sets `waveAnimationEnabled` from `scenePhase`, and `waveReducedMotion` includes `!waveAnimationEnabled`. `WaterLiliesScene` reads `scenePhase` separately and checks both values before starting its tab animation. This repeats the same pause rule in two locations and makes the two conditions appear independent.
- **Simplification**: Remove the scene-local `scenePhase` environment read and use `!reduceMotion && kind == .tab` for the animation branch. The shared modifier remains the single owner of scene playback state.
