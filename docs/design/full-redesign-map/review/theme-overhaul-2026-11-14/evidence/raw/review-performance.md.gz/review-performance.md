# Performance review — a5749e105 vs 96d1a60e5

No performance issues found.

The Water Lilies tab scene now draws up to 560 water dabs, about 51 short strokes, and 21 clusters (15 leaf strokes and 9 flecks each) per Canvas render. This raises the draw cost compared with the base revision, but the drawing is bounded and the 20-second `phaseAnimator` changes an outer offset rather than driving a `TimelineView` or changing the Canvas input every frame. `rendersAsynchronously: true` remains in place. Detail and sheet variants are static and capped at 100/60 dabs and 5/3 clusters. There is no measured frame-time, CPU, or memory regression in the supplied evidence, so reducing the marks or caching paths is an optimization hypothesis, not a P1/P2/P3 finding.

`AmbientScenePlayback` resets only the background decoration identity when Reduce Motion or scene phase changes, and sends `waveAnimationEnabled = false` to the existing theme views. Existing `repeatForever` animations guard on `waveReducedMotion`; recreation therefore stops their layers. The root `TabView` may retain multiple tabs and their decorative animations while the scene is active, but that behavior already existed in the base revision and the patch adds no selected-tab signal. The changed `ViewThatFits` time caption adds a second bounded layout candidate in a single hero caption and is not a performance issue.

Review was read-only for code and execution: no build, test, or simulator commands were run. This report is the requested ignored review artifact.
