#!/usr/bin/env python3
"""NOT EXECUTED: owned Duo theme host audit, one pose per invocation.

Freeze source before running; review/apply duo-open-orientation.patch for
open batches. Hold the repository/worktree simulator lock for every invocation:
  python3 scripts/lib/simulator-test-lock.py "$PWD" -- \
    python3 .codex-checks/theme-overhaul/run-duo-theme-batch.py closed \
      --themes DesertWarm,OceanCool,ForestGreen,SakuraCalm
  python3 scripts/lib/simulator-test-lock.py "$PWD" -- \
    python3 .codex-checks/theme-overhaul/run-duo-theme-batch.py closed \
      --themes ArcticDawn,SolarPop,ContourAtlas,WaterLilies --include-lily-extras
Repeat those two --themes sets with pose open after reviewing/applying the patch.
Each invocation runs at most four theme-root methods; Lily extras are opt-in.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[2]
DEVICE = "D1E42917-AF53-4D67-A382-CB6B87FC5A1D"
HINGE_REPO = Path("/private/tmp/dune-theme-hinge")
HINGE_SCRIPT = HINGE_REPO / "skills/hinge/scripts/hinge"
HINGE_COMMIT = "7acb090dd7d28fb0aea8e1907211ceff15aa450e"
HINGE_SHA256 = "c93cdf0bc0037e00f36ad01677ed27188ba2e85c236e8507f9c51d0bb04a010a"
ORIENTATION_REPO = Path("/private/tmp/dune-theme-serve-sim")
ORIENTATION_COMMIT = "c60d583747b88a15616eeecec56f287ef5759769"
ORIENTATION_MAIN = ORIENTATION_REPO / "packages/serve-sim/Sources/SimDuoHID/main.m"
DRIVER = Path(__file__).with_name("duo-orientation-driver.py")
THEME_NAMES = {
    "DesertWarm": "Desert", "OceanCool": "Ocean",
    "ForestGreen": "Forest", "SakuraCalm": "Sakura",
    "ArcticDawn": "Arctic", "SolarPop": "Solar",
    "ContourAtlas": "Contour", "WaterLilies": "Water Lilies",
}
LILY_EXTRAS = [
    "DUNEUITests/ThemeMatrixUITests/testWaterLiliesMaximumAXRoots",
    "DUNEUITests/ThemeFlowMatrixUITests/testWaterLiliesFlows",
]


def parse_args() -> tuple[str, list[str], bool, list[str]]:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pose", choices=("closed", "open"))
    parser.add_argument("--themes", required=True,
                        help="One to four exact theme IDs, comma-separated; no defaults")
    parser.add_argument("--include-lily-extras", action="store_true",
                        help="Include Water Lilies MAX roots and detail/sheet/workout flow")
    args = parser.parse_args()
    themes = args.themes.split(",")
    if not 1 <= len(themes) <= 4 or len(set(themes)) != len(themes):
        parser.error("--themes requires one to four distinct theme IDs")
    if any(theme not in THEME_NAMES for theme in themes):
        parser.error(f"Unknown theme ID; choose from {','.join(THEME_NAMES)}")
    if args.include_lily_extras and "WaterLilies" not in themes:
        parser.error("--include-lily-extras requires WaterLilies in --themes")
    selectors = [f"DUNEUITests/ThemeMatrixUITests/test{theme}Matrix" for theme in themes]
    if args.include_lily_extras:
        selectors += LILY_EXTRAS
    return args.pose, themes, args.include_lily_extras, selectors


def run(args: list[str], *, env: dict[str, str] | None = None, timeout: int = 40,
        input_text: str | None = None, fds: tuple[int, ...] = ()) -> subprocess.CompletedProcess[str]:
    return subprocess.run(args, cwd=ROOT, env=env, input=input_text, text=True,
                          capture_output=True, timeout=timeout, check=True, pass_fds=fds)


def preflight(pose: str) -> tuple[int, ...]:
    if pose not in ("closed", "open"):
        raise ValueError("Choose exactly one pose: closed or open")
    if Path.cwd().resolve() != ROOT:
        raise ValueError("Run from this Health worktree")
    rows = json.loads((ROOT / ".codex-checks/worktree-simulators.json").read_text())
    record = next((row for row in rows if row.get("udid") == DEVICE), None)
    if not record or record.get("worktree") != str(ROOT) or record.get("preclone_verified") is not True:
        raise ValueError("Duo ownership is not registered for this worktree")
    run(["python3", "scripts/lib/worktree-simulator-registry.py", "is-recorded",
         str(ROOT), DEVICE, record["name"]], timeout=10)
    for repo, expected in ((HINGE_REPO, HINGE_COMMIT), (ORIENTATION_REPO, ORIENTATION_COMMIT)):
        actual = run(["git", "-C", str(repo), "rev-parse", "HEAD"], timeout=10).stdout.strip()
        if actual != expected:
            raise ValueError(f"Pinned external source mismatch: {repo} {actual}")
        if run(["git", "-C", str(repo), "status", "--porcelain"], timeout=10).stdout.strip():
            raise ValueError(f"Pinned external source has local modifications: {repo}")
    if hashlib.sha256(HINGE_SCRIPT.read_bytes()).hexdigest() != HINGE_SHA256:
        raise ValueError("Pinned hinge script SHA-256 mismatch")
    if not ORIENTATION_MAIN.is_file() or not DRIVER.is_file():
        raise ValueError("Pinned orientation main.m/adapter missing")
    helper = (ROOT / "DUNEUITests/Helpers/UITestBaseCase.swift").read_text()
    matrix = (ROOT / "DUNEUITests/Visual/ThemeMatrixUITests.swift").read_text()
    flows = (ROOT / "DUNEUITests/Visual/ThemeFlowMatrixUITests.swift").read_text()
    if pose == "open" and (
            "func reassertDuoOpenLandscapeIfNeeded()" not in helper
            or matrix.count("reassertDuoOpenLandscapeIfNeeded()") < 2
            or "reassertDuoOpenLandscapeIfNeeded()" not in flows):
        raise ValueError("Apply/review duo-open-orientation.patch before open Duo batch")
    scope = os.environ.get("DUNE_SIM_TEST_LOCK_SCOPE", "repository")
    names = ["DUNE_SIM_TEST_LOCK_FD"]
    if scope == "repository":
        names.append("DUNE_SIM_TEST_WORKTREE_LOCK_FD")
    elif scope != "worktree":
        raise ValueError(f"Unknown simulator lock scope: {scope}")
    fds = []
    for name in names:
        value = os.environ.get(name)
        if value is None or not value.isdecimal():
            raise ValueError(f"Missing inherited simulator lock: {name}")
        fd = int(value)
        os.fstat(fd)
        fds.append(fd)
    run(["python3", "scripts/lib/simulator-test-lock.py", str(ROOT), "--verify"],
        timeout=10, fds=tuple(fds))
    return tuple(fds)


def official_readback(out: Path, stage: str) -> tuple[dict, dict]:
    displays = json.loads(run(["xcrun", "devicectl", "device", "info", "displays",
        "--device", DEVICE, "--timeout", "20", "--quiet", "--json-output", "-"], timeout=25).stdout)
    orientation = json.loads(run(["xcrun", "devicectl", "device", "orientation", "get",
        "--device", DEVICE, "--timeout", "10", "--quiet", "--json-output", "-"], timeout=20).stdout)
    (out / f"displays-{stage}.json").write_text(json.dumps(displays, indent=2) + "\n")
    (out / f"orientation-{stage}.json").write_text(json.dumps(orientation, indent=2) + "\n")
    return displays, orientation


def verify_pose(out: Path, stage: str, pose: str, displays: dict, orientation: dict) -> dict:
    rows = displays["result"]["displays"]
    by_name = {row["name"]: row for row in rows}
    target = "LCD" if pose == "closed" else "LCD-1"
    direction = "portrait" if pose == "closed" else "landscapeLeft"
    if set(by_name) != {"LCD", "LCD-1"}:
        raise ValueError(f"Unexpected Duo display inventory: {rows}")
    if not (by_name[target]["active"] and by_name[target]["backlightState"] == "activeOn"
            and not by_name[{"LCD": "LCD-1", "LCD-1": "LCD"}[target]]["active"]):
        raise ValueError(f"{pose} active panel readback mismatch: {rows}")
    actual_direction = orientation["result"]["deviceOrientation"]
    if actual_direction != direction:
        raise ValueError(f"{pose} physical orientation mismatch: {actual_direction}")
    receipt = {"pose": pose, "stage": stage, "active_display": target,
               "active_native_size": by_name[target]["nativeSize"],
               "orientation": actual_direction, "target_angle": 0 if pose == "closed" else 180,
               "actual_angle": None, "angle_readback": "unavailable in current devicectl",
               "verified_by": "official active display/backlight and orientation readback"}
    (out / f"pose-{stage}.json").write_text(json.dumps(receipt, indent=2) + "\n")
    return receipt


def prepare_orientation_driver(out: Path, env: dict[str, str]) -> Path:
    # Pinned build.sh sources scripts/serve-sim-arch.sh, absent from this sparse
    # checkout. Compile the pinned main.m directly with its exact arm64 flags.
    binary_dir = out / "duo-hid-bin"
    binary_dir.mkdir()
    binary = binary_dir / "serve-sim-duo-hid"
    sdk = run(["xcrun", "--sdk", "iphonesimulator", "--show-sdk-path"],
              env=env, timeout=15).stdout.strip()
    run(["xcrun", "--sdk", "iphonesimulator", "clang",
         "-arch", "arm64", "-mios-simulator-version-min=15.0",
         "-isysroot", sdk, "-fobjc-arc", "-framework", "Foundation",
         "-Wl,-adhoc_codesign", "-o", str(binary), str(ORIENTATION_MAIN)],
        env=env, timeout=90)
    if not binary.is_file() or not os.access(binary, os.X_OK):
        raise ValueError("Pinned orientation helper build produced no executable")
    env["DUNE_THEME_DUO_HID_BIN"] = str(binary)
    (out / "driver-source.json").write_text(json.dumps({
        "orientation_commit": ORIENTATION_COMMIT,
        "orientation_source_sha256": hashlib.sha256(ORIENTATION_MAIN.read_bytes()).hexdigest(),
        "orientation_binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
        "orientation_adapter_sha256": hashlib.sha256(DRIVER.read_bytes()).hexdigest(),
        "hinge_commit": HINGE_COMMIT, "hinge_script_sha256": HINGE_SHA256,
        "sdk": sdk,
    }, indent=2) + "\n")
    return binary


def set_orientation(pose: str, env: dict[str, str]) -> None:
    direction = "portrait" if pose == "closed" else "landscapeLeft"
    run([str(DRIVER), "-d", DEVICE, direction], env=env, timeout=30)


def ensure_booted() -> None:
    devices = json.loads(run(["xcrun", "simctl", "list", "devices", "available", "-j"], timeout=30).stdout)
    matches = [row for runtime, entries in devices["devices"].items() if "iOS" in runtime
               for row in entries if row.get("udid") == DEVICE]
    if len(matches) != 1:
        raise ValueError("Owned Duo is unavailable in iOS simulator inventory")
    if matches[0].get("state") != "Booted":
        run(["xcrun", "simctl", "boot", DEVICE], timeout=30)
    run(["xcrun", "simctl", "bootstatus", DEVICE, "-b"], timeout=120)


def png_size(path: Path) -> tuple[int, int]:
    with path.open("rb") as stream:
        header = stream.read(24)
    if header[:8] != b"\x89PNG\r\n\x1a\n" or header[12:16] != b"IHDR":
        raise ValueError(f"Invalid native PNG: {path}")
    return struct.unpack(">II", header[16:24])


def pair_native_evidence(out: Path, pose: str, display_receipt: dict,
                         themes: list[str], include_lily_extras: bool) -> None:
    expected = tuple(display_receipt["active_native_size"])
    checkpoints = [json.loads(line) for line in (out / "checkpoints.jsonl").read_text().splitlines()]
    if not checkpoints or any(not row["valid_evidence"] for row in checkpoints):
        raise ValueError("Missing/unacknowledged fresh host capture checkpoint")
    capture_rows = [line.split("\t") for line in (out / "captures.tsv").read_text().splitlines()]
    pairs = []
    for checkpoint in checkpoints:
        sequence = checkpoint["sequence"]
        prefix = f"{sequence:03}-"
        matching = [row for row in capture_rows if row[0].startswith(prefix)]
        if len(matching) != 2 or any(row[2:] != ["0", "1"] for row in matching):
            raise ValueError(f"Checkpoint {sequence} lacks both valid native displays")
        pngs = [out / f"{row[0]}.png" for row in matching]
        if any(not path.is_file() or path.stat().st_size == 0 for path in pngs):
            raise ValueError(f"Checkpoint {sequence} native PNG missing")
        active = [path for path in pngs if path.stem.endswith(f"-{expected[0]}x{expected[1]}")]
        if len(active) != 1:
            raise ValueError(f"Checkpoint {sequence} cannot pair active {expected} display")
        dimensions = png_size(active[0])
        if sorted(dimensions) != sorted(expected):
            raise ValueError(f"Checkpoint {sequence} active PNG dimensions mismatch: {dimensions}")
        hierarchy = out / f"{sequence:03}-hierarchy.txt"
        if not hierarchy.is_file() or hierarchy.stat().st_size == 0:
            raise ValueError(f"Checkpoint {sequence} fresh AX hierarchy missing")
        window = re.search(r"Window,.*?\{\{[^}]+\}, \{([0-9.]+), ([0-9.]+)\}\}",
                           hierarchy.read_text(errors="replace"))
        if not window:
            raise ValueError(f"Checkpoint {sequence} lacks an AX window viewport")
        width, height = map(float, window.groups())
        if min(width, height) <= 0:
            raise ValueError(f"Checkpoint {sequence} has an empty AX viewport")
        pixels = sorted(dimensions)
        points = sorted((width, height))
        scales = [pixel / point for pixel, point in zip(pixels, points)]
        if abs(scales[0] - scales[1]) > max(0.02, max(scales) * 0.01):
            raise ValueError(f"Checkpoint {sequence} active PNG/AX panel mismatch: {dimensions}, {width}x{height}")
        # Setup/tap checkpoints can precede explicit theme orientation after
        # a fresh app launch. Preserve their PNG+AX without calling them a root.
        is_canonical = any(
            f"{THEME_NAMES[theme]} {style} {tab}" in checkpoint["action"]
            for theme in themes for style in ("Light", "Dark")
            for tab in ("Today", "Activity", "Wellness", "Life")
        ) or (include_lily_extras and any(
            f"Water Lilies {state}" in checkpoint["action"]
            for state in ("MAX Today", "MAX Activity", "MAX Wellness", "MAX Life",
                          "Light Detail", "Light Sheet", "Light Workout",
                          "Dark Detail", "Dark Sheet", "Dark Workout")
        ))
        if is_canonical and ((pose == "open" and width <= height)
                             or (pose == "closed" and width >= height)):
            raise ValueError(f"Canonical checkpoint {sequence} wrong AX viewport: {width}x{height}")
        pairs.append({"sequence": sequence, "action": checkpoint["action"],
                      "canonical_theme_capture": is_canonical,
                      "active_display": display_receipt["active_display"],
                      "active_png": str(active[0]), "paired_pngs": [str(p) for p in pngs],
                      "active_png_dimensions": dimensions, "ax": str(hierarchy),
                      "ax_viewport": [width, height], "pixel_scales": scales, "actual_angle": None})
    (out / "pairs.json").write_text(json.dumps(pairs, indent=2) + "\n")
    actions = "\n".join(row["action"] for row in checkpoints)
    for theme in (THEME_NAMES[theme_id] for theme_id in themes):
        for style in ("Light", "Dark"):
            for tab in ("Today", "Activity", "Wellness", "Life"):
                if f"{theme} {style} {tab}" not in actions:
                    raise ValueError(f"Missing fresh root capture: {theme} {style} {tab}")
    if include_lily_extras:
        for state in ("MAX Today", "MAX Activity", "MAX Wellness", "MAX Life",
                      "Light Detail", "Light Sheet", "Light Workout",
                      "Dark Detail", "Dark Sheet", "Dark Workout"):
            if f"Water Lilies {state}" not in actions:
                raise ValueError(f"Missing fresh Lily capture: {state}")


def main() -> int:
    pose, themes, include_lily_extras, selectors = parse_args()
    fds = preflight(pose)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    label = "-".join(themes)
    out = ROOT / ".codex-checks/theme-overhaul" / f"duo-theme-{pose}-{label}-{stamp}"
    out.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ)
    env["DEVELOPER_DIR"] = run(["xcode-select", "-p"], timeout=10).stdout.strip()
    env["XDG_CACHE_HOME"] = str(out / "hinge-cache")
    env["DUNE_UI_TEST_WALL_TIMEOUT"] = "1200"
    ensure_booted()
    before_displays, before_orientation = official_readback(out, "before")
    prepare_orientation_driver(out, env)
    target_angle = "0" if pose == "closed" else "180"
    setter = run([str(HINGE_SCRIPT), "-d", DEVICE, target_angle], env=env, timeout=60)
    (out / "hinge-set.log").write_text(setter.stdout + setter.stderr)
    set_orientation(pose, env)
    after_displays, after_orientation = official_readback(out, "after")
    receipt = verify_pose(out, "after", pose, after_displays, after_orientation)
    (out / "preflight.json").write_text(json.dumps({
        "device": DEVICE, "pose": pose, "source_hinge_commit": HINGE_COMMIT,
        "source_orientation_commit": ORIENTATION_COMMIT, "selectors": selectors,
        "theme_ids": themes, "include_lily_extras": include_lily_extras,
        "before_displays": before_displays["result"]["displays"],
        "before_orientation": before_orientation["result"], "after": receipt,
    }, indent=2) + "\n")
    log = out / "ui.log"
    command = ["python3", "scripts/duo-visual-audit.py", str(out), DEVICE, "all",
               "scripts/test-ui.sh", "--no-regen", "--stream-log",
               "--test-plan", "DUNEUITests-DuoAudit", "--simulator-udid", DEVICE,
               "--log-file", str(log),
               *[part for selector in selectors for part in ("--only-testing", selector)]]
    env["DAILVE_DUO_ORIENTATION_CLI"] = str(DRIVER)
    try:
        completed = run(command, env=env, timeout=1320, fds=fds)
        (out / "host-stdout.log").write_text(completed.stdout + completed.stderr)
    except subprocess.CalledProcessError as error:
        (out / "host-stdout.log").write_text((error.stdout or "") + (error.stderr or ""))
        official_readback(out, "post-failure")
        raise
    post_displays, post_orientation = official_readback(out, "post-test")
    verify_pose(out, "post-test", pose, post_displays, post_orientation)
    result = json.loads(Path(f"{log}.result.json").read_text())
    if result.get("status") != "passed" or result.get("counts", {}).get("passed") != len(selectors):
        raise ValueError(f"Targeted UI selector receipt failed: {result}")
    runner = json.loads((out / "runner-result.json").read_text())
    if runner.get("returncode") != 0 or runner.get("termination") or runner.get("cleanup_error"):
        raise ValueError(f"Host capture runner did not complete cleanly: {runner}")
    pair_native_evidence(out, pose, receipt, themes, include_lily_extras)
    print(f"Duo {pose}: {len(selectors)} selectors, paired native PNG + AX in {out}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, subprocess.SubprocessError, KeyError, IndexError) as error:
        print(f"Duo theme batch incomplete: {error}", file=sys.stderr)
        raise SystemExit(2)
