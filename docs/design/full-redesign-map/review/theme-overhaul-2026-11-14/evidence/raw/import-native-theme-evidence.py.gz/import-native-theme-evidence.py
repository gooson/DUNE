#!/usr/bin/env python3
"""Stage an eight-theme, light/dark four-tab PNG+AX evidence set.

This helper never writes into a design map. It requires explicit provenance for
each theme export and creates a new output directory only.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import shutil
import sys
import struct


ROOT = Path(__file__).resolve().parents[2]
COLLECTOR_PATH = ROOT / "docs/design/full-redesign-map/collect-theme-captures.py"
THEME_KEYS = {
    "Desert": "dune",
    "Ocean": "ocean",
    "Forest": "forest",
    "Sakura": "sakura",
    "Arctic": "arctic",
    "Solar": "solar",
    "Contour": "contour",
    "Water Lilies": "water-lilies",
}
SCENES = {"Today": "T03", "Activity": "A01", "Wellness": "H01", "Life": "L01"}
SCREENSHOT_RE = re.compile(
    r"^screen-(?P<index>\d+)-(?P<width>\d+)x(?P<height>\d+)-"
    r"(?P<label>(?:Desert|Ocean|Forest|Sakura|Arctic|Solar|Contour|Water Lilies) "
    r"(?:Light|Dark) (?:Today|Activity|Wellness|Life))_\d+_[0-9a-fA-F-]{36}\.png$"
)
HIERARCHY_RE = re.compile(
    r"^hierarchy-(?P<label>(?:Desert|Ocean|Forest|Sakura|Arctic|Solar|Contour|Water Lilies) "
    r"(?:Light|Dark) (?:Today|Activity|Wellness|Life))-[A-Za-z0-9_.]+_\d+_"
    r"[0-9a-fA-F-]{36}\.swift-\d+$"
)


def mapping(value: str, what: str) -> tuple[str, Path]:
    if "=" not in value:
        raise argparse.ArgumentTypeError(f"{what} must be THEME=PATH")
    name, path = value.split("=", 1)
    if name not in THEME_KEYS or not path:
        raise argparse.ArgumentTypeError(f"invalid {what}: {value}")
    return name, Path(path)


def collector_module():
    spec = importlib.util.spec_from_file_location("theme_capture_collector", COLLECTOR_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load collector: {COLLECTOR_PATH}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def png_dimensions(path: Path) -> tuple[int, int]:
    """Read and validate the PNG IHDR dimensions without decoding pixels."""
    with path.open("rb") as stream:
        header = stream.read(24)
    if len(header) != 24 or header[:8] != b"\x89PNG\r\n\x1a\n" or header[12:16] != b"IHDR":
        raise ValueError(f"invalid PNG signature/IHDR: {path}")
    width, height = struct.unpack(">II", header[16:24])
    if width <= 0 or height <= 0:
        raise ValueError(f"invalid PNG dimensions: {path}")
    return width, height


def ax_logical_viewport(path: Path) -> str:
    """Extract the first Window (Main) bounds in AX points, distinct from PNG pixels."""
    text = path.read_text(encoding="utf-8", errors="replace")
    for line in text.splitlines():
        if "Window (Main)" not in line:
            continue
        match = re.search(r"\{\{\s*-?[\d.]+\s*,\s*-?[\d.]+\s*\},\s*\{\s*([\d.]+)\s*,\s*([\d.]+)\s*\}\}", line)
        if match:
            return f"{match.group(1)}x{match.group(2)} pt"
    raise ValueError(f"AX hierarchy has no parseable Window (Main) bounds: {path}")


def extract_theme(theme: str, export_dir: Path, expected_udid: str | None, collector) -> dict[str, dict]:
    manifest_path = export_dir / "manifest.json"
    if not manifest_path.is_file():
        raise ValueError(f"missing manifest for {theme}: {manifest_path}")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(manifest, list):
        raise ValueError(f"expected attachment list in {manifest_path}")
    selected = {}
    observed_udids = set()
    for test in manifest:
        if not isinstance(test, dict):
            continue
        selector = test.get("testIdentifier", "")
        if not re.fullmatch(r"ThemeMatrixUITests/test[A-Za-z0-9]+Matrix\(\)", selector):
            continue
        pairs = {}
        for attachment in test.get("attachments", []):
            if not isinstance(attachment, dict) or attachment.get("isAssociatedWithFailure", False):
                continue
            original = attachment.get("suggestedHumanReadableName", "")
            screenshot = SCREENSHOT_RE.fullmatch(original)
            hierarchy = HIERARCHY_RE.fullmatch(original)
            if not screenshot and not hierarchy:
                continue
            label = (screenshot or hierarchy).group("label")
            theme_name, appearance, screen_name = label.rsplit(" ", 2)
            if theme_name != theme:
                continue
            exported_name = attachment.get("exportedFileName")
            file_path = export_dir / str(exported_name or "")
            if not exported_name or not file_path.is_file():
                raise ValueError(f"manifest attachment file missing: {original}")
            attachment_udid = attachment.get("deviceId", "")
            if not attachment_udid:
                raise ValueError(f"attachment has no device UDID: {original}")
            observed_udids.add(attachment_udid.lower())
            if expected_udid and attachment_udid.lower() != expected_udid.lower():
                raise ValueError(f"device UDID mismatch for attachment: {original}")
            slot = pairs.setdefault(label, {})
            if screenshot:
                if "png" in slot:
                    raise ValueError(f"duplicate root screenshot for {label} in {theme}")
                slot["png"] = (attachment, file_path)
                slot["named_pixels"] = (int(screenshot.group("width")), int(screenshot.group("height")))
            else:
                if "ax" in slot:
                    raise ValueError(f"duplicate hierarchy for {label} in {theme}")
                slot["ax"] = (attachment, file_path)

        for label, pair in pairs.items():
            pair_theme, appearance, screen_name = label.rsplit(" ", 2)
            if set(pair) != {"png", "ax", "named_pixels"}:
                raise ValueError(f"missing PNG or friendly-name paired AX attachment for {label} in {theme}")
            png, png_path = pair["png"]
            ax, ax_path = pair["ax"]
            activity = re.compile(r"_\d+_([0-9a-fA-F-]{36})(?:\.png|\.swift-\d+)$")
            png_id = activity.search(png["suggestedHumanReadableName"])
            ax_id = activity.search(ax["suggestedHumanReadableName"])
            if not png_id or not ax_id or png_id[1] != ax_id[1]:
                raise ValueError(f"PNG/AX capture activity does not match for {label}")
            stamps = [float(item["timestamp"]) for item in (png, ax)]
            if not all(math.isfinite(stamp) for stamp in stamps) or abs(stamps[0] - stamps[1]) > 5:
                raise ValueError(f"PNG/AX timestamps are not adjacent for {label}")
            if png.get("deviceId", "").lower() != ax.get("deviceId", "").lower():
                raise ValueError(f"PNG/AX devices do not match for {label}")
            actual_pixels = png_dimensions(png_path)
            if actual_pixels != pair["named_pixels"]:
                raise ValueError(f"PNG IHDR {actual_pixels} does not match filename {pair['named_pixels']} for {label}")
            logical_viewport = ax_logical_viewport(ax_path)
            classified = collector.classify_attachment(png["suggestedHumanReadableName"])
            if classified is None:
                raise ValueError(f"collector did not classify screenshot name: {label}")
            theme_id, appearance_id, screen_id = classified
            expected = f"{pair_theme} {appearance} {screen_name}"
            if label != expected:
                raise ValueError(f"unexpected canonical root label: {label!r} != {expected!r}")
            key = f"{theme_id}/{appearance_id}/{screen_id}"
            if key in selected:
                raise ValueError(f"duplicate canonical capture {key} in {theme}")
            width, height = actual_pixels
            selected[key] = {
                "theme": theme_id,
                "appearance": appearance_id,
                "screen_id": screen_id,
                "file": f"images/{theme_id}/{appearance_id}/{screen_id}.png",
                "ax_file": f"ax/{theme_id}/{appearance_id}/{screen_id}.txt",
                "attachment_name": png["suggestedHumanReadableName"],
                "ax_attachment_name": ax["suggestedHumanReadableName"],
                "test_identifier": test["testIdentifier"],
                "timestamp": png.get("timestamp"),
                "ax_timestamp": ax.get("timestamp"),
                "viewport": f"{width}x{height}",
                "viewport_pixels": f"{width}x{height} px",
                "logical_viewport_points": logical_viewport,
                "export_manifest": str(manifest_path.resolve()),
                "device": None,
                "sha256_png": sha256(png_path),
                "sha256_ax": sha256(ax_path),
            }
            selected[key]["_png_source"] = png_path
            selected[key]["_ax_source"] = ax_path
    if len(observed_udids) != 1:
        raise ValueError(f"{theme} attachments must share one device UDID; found {sorted(observed_udids)}")
    theme_expected = {f"{THEME_KEYS[theme]}/{appearance}/{screen}" for appearance in ("light", "dark")
                      for screen in SCENES.values()}
    if set(selected) != theme_expected:
        missing = sorted(theme_expected - set(selected))
        extra = sorted(set(selected) - theme_expected)
        raise ValueError(f"{theme} must provide exactly 8 canonical roots; missing={missing}, extra={extra}")
    return selected


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--theme-export", action="append", metavar="THEME=DIR",
                        help="export directory containing manifest.json and its attachment files; repeat for all 8 themes")
    parser.add_argument("--batch-log", action="append", metavar="THEME=FILE",
                        help="authoritative test runner log for that theme; repeat for all 8 themes")
    parser.add_argument("--batch-provenance", action="append", metavar="[THEME=]FILE",
                        help="authoritative batch metadata JSON (one common file or one per theme)")
    parser.add_argument("--source-revision", help="tested source commit/revision, supplied by caller")
    parser.add_argument("--source-worktree", help="tested worktree path, supplied by caller")
    parser.add_argument("--device-udid", help="expected simulator UDID; checked against manifest")
    parser.add_argument("--device-description", help="human-readable device model/name from caller")
    parser.add_argument("--device-kind", choices=("regular", "ipad", "duo", "duo-open"), default="regular")
    parser.add_argument("--output", type=Path, help="new staging directory; must not already exist")
    parser.add_argument("--self-check-export", metavar="THEME=DIR",
                        help="validate one existing export set without staging; currently useful for Forest 8-pair check")
    args = parser.parse_args()
    args.self_check = None
    if args.self_check_export:
        try:
            args.self_check = mapping(args.self_check_export, "--self-check-export")
        except argparse.ArgumentTypeError as error:
            parser.error(str(error))
        return args
    if not args.theme_export or not args.batch_log:
        parser.error("staging requires --theme-export and --batch-log for all eight themes")
    try:
        export_pairs = [mapping(value, "--theme-export") for value in args.theme_export]
        log_pairs = [mapping(value, "--batch-log") for value in args.batch_log]
    except argparse.ArgumentTypeError as error:
        parser.error(str(error))
    if len({name for name, _ in export_pairs}) != len(export_pairs) or len({name for name, _ in log_pairs}) != len(log_pairs):
        parser.error("each theme may appear only once in --theme-export and --batch-log")
    args.exports = dict(export_pairs)
    args.logs = dict(log_pairs)
    if set(args.exports) != set(THEME_KEYS) or set(args.logs) != set(THEME_KEYS):
        parser.error("provide exactly one export directory and batch log for every canonical theme")
    if not args.source_revision or not args.source_revision.strip() or not args.source_worktree or not args.source_worktree.strip() or not args.device_udid or not args.device_udid.strip():
        parser.error("source revision, source worktree, and device UDID must be non-empty")
    if not args.device_description or not args.device_description.strip() or not args.output:
        parser.error("device description and fresh output path are required")
    if args.output.exists():
        parser.error(f"output must be a fresh path: {args.output}")
    if not args.batch_provenance:
        parser.error("provide authoritative --batch-provenance metadata")
    batch_pairs = []
    for value in args.batch_provenance:
        if "=" in value:
            batch_pairs.append(mapping(value, "--batch-provenance"))
        else:
            batch_pairs.append(("*", Path(value)))
    if len(batch_pairs) == 1 and batch_pairs[0][0] == "*":
        args.provenance = {theme: batch_pairs[0][1] for theme in THEME_KEYS}
    elif len({name for name, _ in batch_pairs}) == len(batch_pairs) and set(name for name, _ in batch_pairs) == set(THEME_KEYS):
        args.provenance = dict(batch_pairs)
    else:
        parser.error("batch provenance must be one common FILE or exactly one THEME=FILE for each theme")
    return args


def main() -> int:
    args = parse_args()
    collector = collector_module()
    if args.self_check:
        theme, export_dir = args.self_check
        selected = extract_theme(theme, export_dir, args.device_udid, collector)
        pixel_viewports = sorted({capture["viewport_pixels"] for capture in selected.values()})
        logical_viewports = sorted({capture["logical_viewport_points"] for capture in selected.values()})
        print(f"Validated {len(selected)} PNG+AX pairs for {theme}: pixels={pixel_viewports}, AX points={logical_viewports}")
        return 0

    captures: dict[str, dict] = {}
    device = {"kind": args.device_kind, "platform": "iOS Simulator", "model_name": args.device_description, "identifier": args.device_udid}
    batches = {}
    pixel_viewports = set()
    logical_viewports = set()

    for theme, export_dir in args.exports.items():
        log_path = args.logs[theme]
        provenance_path = args.provenance[theme]
        if not log_path.is_file() or not provenance_path.is_file():
            raise ValueError(f"missing caller-supplied batch log or provenance for {theme}")
        provenance = json.loads(provenance_path.read_text(encoding="utf-8"))
        if not isinstance(provenance, dict):
            raise ValueError(f"batch provenance must be a JSON object: {provenance_path}")
        dirty = provenance.get("source_worktree_dirty")
        if dirty is not None and not isinstance(dirty, bool):
            raise ValueError(f"source_worktree_dirty must be boolean when present: {provenance_path}")
        batches[theme] = {
            "log": str(log_path.resolve()),
            "log_sha256": sha256(log_path),
            "provenance": str(provenance_path.resolve()),
            "provenance_sha256": sha256(provenance_path),
            "source_worktree_dirty": dirty,
        }
        selected = extract_theme(theme, export_dir, args.device_udid, collector)
        for record in selected.values():
            record["device"] = device
            record["source_revision"] = args.source_revision
            record["source_worktree"] = args.source_worktree
            record["source_worktree_dirty"] = dirty
            record["batch_log"] = batches[theme]["log"]
            record["batch_provenance"] = batches[theme]["provenance"]
            pixel_viewports.add(record["viewport_pixels"])
            logical_viewports.add(record["logical_viewport_points"])
        captures.update(selected)

    if len(captures) != 64:
        raise ValueError(f"expected 64 unique roots, found {len(captures)}")
    if len(pixel_viewports) != 1 or len(logical_viewports) != 1:
        raise ValueError(f"all 64 screenshots must share one pixel and logical viewport; pixels={sorted(pixel_viewports)}, AX points={sorted(logical_viewports)}")

    args.output.mkdir(parents=True)
    try:
        for record in captures.values():
            png_source = record.pop("_png_source")
            ax_source = record.pop("_ax_source")
            for field in ("file", "ax_file"):
                (args.output / record[field]).parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(png_source, args.output / record["file"])
            shutil.copyfile(ax_source, args.output / record["ax_file"])
        payload = {
            "schema_version": 1,
            "device": device,
            "viewport_pixels": next(iter(pixel_viewports)),
            "logical_viewport_points": next(iter(logical_viewports)),
            "source_revision": args.source_revision,
            "source_worktree": args.source_worktree,
            "batches": batches,
            "captures": captures,
        }
        (args.output / "provenance.json").write_text(
            json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
    except BaseException:
        shutil.rmtree(args.output, ignore_errors=True)
        raise
    print(f"Staged {len(captures)} PNG+AX pairs at {args.output} ({payload['viewport_pixels']}; AX {payload['logical_viewport_points']})")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, json.JSONDecodeError) as error:
        print(f"error: {error}", file=sys.stderr)
        raise SystemExit(2)
