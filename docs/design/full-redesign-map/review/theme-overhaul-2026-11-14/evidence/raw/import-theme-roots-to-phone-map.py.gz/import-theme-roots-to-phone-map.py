#!/usr/bin/env python3
"""Refresh only T03/A01/H01/L01 in a phone actual-map index from its theme stage.

Default mode is a dry-run. --apply atomically replaces those four PNG/AX
files and updates only those capture records plus last-refresh metadata.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import struct
import tempfile
import sys


ROOT = Path(__file__).resolve().parents[2]
MAP_ROOT = ROOT / "docs/design/phone-design-map/actual"
SCREEN_LABELS = {"T03": "Today", "A01": "Activity", "H01": "Wellness", "L01": "Life"}


def load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as stream:
        header = stream.read(24)
    if len(header) != 24 or header[:8] != b"\x89PNG\r\n\x1a\n" or header[12:16] != b"IHDR":
        raise ValueError(f"invalid PNG/IHDR: {path}")
    return struct.unpack(">II", header[16:24])


def atomic_copy(source: Path, destination: Path, expected_hash: str) -> None:
    if sha256(source) != expected_hash:
        raise ValueError(f"staged source changed: {source}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{destination.name}.", dir=destination.parent)
    os.close(descriptor)
    temporary = Path(temporary_name)
    try:
        shutil.copyfile(source, temporary)
        if sha256(temporary) != expected_hash:
            raise ValueError(f"copy hash mismatch: {destination}")
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)


def inspect(kind: str, stage: Path) -> dict:
    stage = stage.resolve()
    target = MAP_ROOT / kind
    stage_manifest = stage / "provenance.json"
    stage_data = load_json(stage_manifest)
    device = stage_data.get("device")
    if not isinstance(device, dict) or device.get("kind") != kind or not device.get("identifier"):
        raise ValueError(f"stage device metadata does not match {kind}")
    if stage_data.get("source_worktree_dirty") not in (None, False):
        raise ValueError("stage-level source_worktree_dirty, when present, must be false")
    source_revision = stage_data.get("source_revision")
    source_worktree = stage_data.get("source_worktree")
    captures = stage_data.get("captures")
    if not isinstance(source_revision, str) or not source_revision or not isinstance(source_worktree, str) or not source_worktree:
        raise ValueError("stage source revision/worktree missing")
    if not isinstance(captures, dict):
        raise ValueError("stage captures must be an object")
    expected = {f"dune/light/{screen}" for screen in SCREEN_LABELS}
    for key, record in captures.items():
        if key in expected:
            continue
    missing = expected - set(captures)
    if missing:
        raise ValueError(f"stage is missing DUNE light roots: {sorted(missing)}")

    index_path = target / "capture-index.json"
    index = load_json(index_path)
    existing = index.get("captured")
    if not isinstance(existing, dict):
        raise ValueError(f"phone actual-map index has no captured dictionary: {index_path}")
    replacements = {}
    for screen in SCREEN_LABELS:
        key = f"dune/light/{screen}"
        incoming = captures[key]
        if not isinstance(incoming, dict) or incoming.get("source_worktree_dirty") is not False:
            raise ValueError(f"root provenance is not clean/authoritative: {key}")
        if incoming.get("source_revision") != source_revision:
            raise ValueError(f"root source revision disagrees with stage: {key}")
        if incoming.get("device") != device:
            raise ValueError(f"root device metadata disagrees with stage: {key}")
        if incoming.get("file") != f"images/{key}.png" or incoming.get("ax_file") != f"ax/{key}.txt":
            raise ValueError(f"stage PNG/AX paths are not canonical: {key}")
        png_source = stage / incoming["file"]
        ax_source = stage / incoming["ax_file"]
        if not png_source.is_file() or not ax_source.is_file():
            raise ValueError(f"stage PNG or AX source missing: {key}")
        png_hash = sha256(png_source)
        ax_hash = sha256(ax_source)
        if incoming.get("sha256_png") != png_hash or incoming.get("sha256_ax") != ax_hash:
            raise ValueError(f"stage PNG/AX hash mismatch: {key}")
        actual_pixels = png_dimensions(png_source)
        if incoming.get("viewport_pixels") != f"{actual_pixels[0]}x{actual_pixels[1]} px":
            raise ValueError(f"stage PNG dimensions disagree with provenance: {key}")
        if not isinstance(incoming.get("logical_viewport_points"), str):
            raise ValueError(f"stage AX logical viewport missing: {key}")
        try:
            timestamp = float(incoming["timestamp"])
        except (KeyError, TypeError, ValueError):
            raise ValueError(f"root original timestamp missing: {key}")
        if not math.isfinite(timestamp):
            raise ValueError(f"root original timestamp invalid: {key}")
        previous = existing.get(screen)
        if not isinstance(previous, dict):
            raise ValueError(f"existing actual-map screen missing: {screen}")
        try:
            old_timestamp = float(previous.get("timestamp"))
        except (TypeError, ValueError):
            raise ValueError(f"existing timestamp invalid: {screen}")
        if not math.isfinite(old_timestamp) or timestamp <= old_timestamp:
            raise ValueError(f"incoming root is not newer than existing screen: {screen}")
        png_target = target / "images" / f"{screen}.png"
        ax_target = target / "ax" / f"{screen}.txt"
        if not png_target.is_file():
            raise ValueError(f"existing canonical PNG target missing: {screen}")

        record = dict(incoming)
        record.update({
            "row_id": screen,
            "evidence": "DUNE light theme-matrix root",
            "test": incoming["test_identifier"],
            "action": incoming["attachment_name"],
            "screen": incoming["attachment_name"],
            "file": f"{screen}.png",
            "ax_file": f"ax/{screen}.txt",
            "source_revision": source_revision,
            "source_worktree_dirty": False,
            "device_id": device["identifier"],
            "device_name": device["model_name"],
            "native_size": list(actual_pixels),
            "sha256": png_hash,
            "ax_sha256": ax_hash,
            "capture_kind": "XCTest-native-PNG+AX",
            "source_json": f"../../../full-redesign-map/actual/{kind}/capture-index.json",
            "phone_map_source_provenance": str(stage_manifest),
        })
        if "pose" in incoming:
            record["posture"] = incoming["pose"]
        record["viewport_pixels"] = incoming["viewport_pixels"]
        record["logical_viewport_points"] = incoming["logical_viewport_points"]
        replacements[screen] = {
            "record": record,
            "png_source": png_source,
            "ax_source": ax_source,
            "png_target": png_target,
            "ax_target": ax_target,
            "sha256_png": png_hash,
            "sha256_ax": ax_hash,
            "timestamp": timestamp,
            "old_timestamp": old_timestamp,
        }
    new_index = dict(index)
    new_index["captured"] = dict(existing)
    for screen, item in replacements.items():
        new_index["captured"][screen] = item["record"]
    new_index["last_refresh_revision"] = source_revision
    new_index["last_refresh_screens"] = list(SCREEN_LABELS)
    new_index["last_refresh_note"] = (
        f"DUNE light theme-matrix roots from {stage.name}; only T03/A01/H01/L01 refreshed, "
        "other entries retain their original images and provenance."
    )
    return {
        "kind": kind,
        "stage": stage,
        "stage_manifest": stage_manifest,
        "target": target,
        "index_path": index_path,
        "index_sha256": sha256(index_path),
        "device": device,
        "source_revision": source_revision,
        "source_worktree_dirty": False,
        "replacements": replacements,
        "index": new_index,
    }


def apply(plan: dict) -> None:
    if sha256(plan["index_path"]) != plan["index_sha256"]:
        raise ValueError(f"phone actual-map index changed after planning: {plan['index_path']}")
    for item in plan["replacements"].values():
        atomic_copy(item["png_source"], item["png_target"], item["sha256_png"])
        atomic_copy(item["ax_source"], item["ax_target"], item["sha256_ax"])
    descriptor, temporary_name = tempfile.mkstemp(prefix=".capture-index.", suffix=".json", dir=plan["target"])
    os.close(descriptor)
    temporary = Path(temporary_name)
    try:
        temporary.write_text(json.dumps(plan["index"], ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(temporary, plan["index_path"])
    finally:
        temporary.unlink(missing_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("kind", choices=("regular", "ipad", "duo", "duo-open"))
    parser.add_argument("--stage", type=Path, help="full-redesign stage (default stage-<kind>)")
    parser.add_argument("--apply", action="store_true", help="copy the four PNG/AX pairs and replace their index rows")
    args = parser.parse_args()
    stage = args.stage or ROOT / f".codex-checks/theme-overhaul/stage-{args.kind}"
    plan = inspect(args.kind, stage)
    print(f"{'APPLY' if args.apply else 'DRY-RUN'} phone actual {args.kind}: DUNE Light T03/A01/H01/L01")
    print(f"Device: {plan['device'].get('model_name')} [{plan['device'].get('identifier')}]; source {plan['source_revision']} dirty=false")
    for screen, item in plan["replacements"].items():
        print(f"{screen}: {item['old_timestamp']} -> {item['timestamp']}; PNG {item['sha256_png'][:12]} AX {item['sha256_ax'][:12]}")
    print(f"Targets: {plan['target']}/images/<screen>.png and ax/<screen>.txt")
    if args.apply:
        apply(plan)
        print("Four-screen refresh complete.")
    else:
        print("Dry-run only; no tracked files written. Add --apply after review.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, json.JSONDecodeError) as error:
        print(f"error: {error}", file=sys.stderr)
        raise SystemExit(2)
