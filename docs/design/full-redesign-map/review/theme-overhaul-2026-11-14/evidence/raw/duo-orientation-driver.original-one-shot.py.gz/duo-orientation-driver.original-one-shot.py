#!/usr/bin/env python3
"""Task-local, pinned SimDuoHID adapter for duo-visual-audit.py ORIENT checkpoints."""
import os
import subprocess
import sys
from pathlib import Path

DEVICE = "D1E42917-AF53-4D67-A382-CB6B87FC5A1D"
TOKENS = {"portrait": "1", "landscapeLeft": "3", "landscapeRight": "4"}


def main() -> int:
    if len(sys.argv) != 4 or sys.argv[1:3] != ["-d", DEVICE] or sys.argv[3] not in TOKENS:
        raise SystemExit("Expected -d <owned Duo UDID> portrait|landscapeLeft|landscapeRight")
    binary = Path(os.environ["DUNE_THEME_DUO_HID_BIN"]).resolve(strict=True)
    if not binary.is_file() or not os.access(binary, os.X_OK):
        raise SystemExit("Pinned Duo orientation binary is unavailable")
    result = subprocess.run(
        ["xcrun", "simctl", "spawn", DEVICE, str(binary)],
        input=f"orientation {TOKENS[sys.argv[3]]}\n", text=True,
        capture_output=True, timeout=20,
    )
    if result.returncode or "OK" not in result.stdout.splitlines():
        raise SystemExit(f"Duo orientation dispatch failed: {result.returncode} {result.stderr[-400:]}")
    print("OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
