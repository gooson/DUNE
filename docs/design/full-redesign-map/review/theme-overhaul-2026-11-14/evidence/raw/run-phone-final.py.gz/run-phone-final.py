import subprocess,sys
base=['python3','scripts/codex-pipeline.py','run']
def run(name,setting,selectors):
 cmd=base+[name,'--context','xcode27B52-ios27.2-c50647199-final-phone','--scope','all','--content-only','--','python3','scripts/lib/simulator-test-lock.py','.','--','python3','.codex-checks/theme-overhaul/run-native-batch.py',name,'9D0602F1-9D0B-4AB0-B144-666748CCDC19']
 if setting:cmd+=['--setting',setting]
 cmd+=selectors
 print('Starting '+name,flush=True)
 r=subprocess.call(cmd)
 if r:sys.exit(r)
run('phone-high-contrast','contrast',['DUNEUITests/ThemeMatrixUITests/testWaterLiliesMatrix'])
run('phone-final-roots',None,['DUNEUITests/ThemeMatrixUITests/test'+t+'Matrix' for t in ['DesertWarm','OceanCool','ForestGreen','SakuraCalm','ArcticDawn','SolarPop','ContourAtlas','WaterLilies']])
