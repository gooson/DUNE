#!/usr/bin/env python3
"""Stage the passed Water Lilies iPad and Duo extra native captures."""

from __future__ import annotations

import hashlib
import html
import json
from pathlib import Path
import re
import shutil
import struct
import sys


ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / ".codex-checks/theme-overhaul"
IPAD_EXPORT = WORK / "exports/ipad-native"
IPAD_PROOF = WORK / "ipad-native-provenance.json"
IPAD_RECEIPT = WORK / "ipad-native.log.result.json"
DUO_BATCH = WORK / "duo-theme-closed-WaterLilies-20261114T124643Z"
PHONE_ACCESSIBILITY = {
    "phone-voiceover-fixed": {
        "selector": "DUNEUITests/WaterLiliesThemeTests/testVoiceOverConditionDetailEntryAndReturn",
        "proof": WORK / "phone-voiceover-fixed-provenance.json",
        "receipt": WORK / "phone-voiceover-fixed.log.result.json",
        "setting": "voiceover",
        "before": WORK / "phone-voiceover-fixed-before.json",
        "enabled": WORK / "phone-voiceover-fixed-enabled.json",
        "restored": WORK / "phone-voiceover-fixed-restored.json",
        "labels": {"Water Lilies VoiceOver Today root": "T03", "Water Lilies VoiceOver Condition detail": "CONDITION_DETAIL", "Water Lilies VoiceOver Today returned": "T03_RETURNED"},
    },
    "phone-high-contrast": {
        "selector": "DUNEUITests/ThemeMatrixUITests/testWaterLiliesMatrix",
        "proof": WORK / "phone-high-contrast-provenance.json",
        "receipt": WORK / "phone-high-contrast.log.result.json",
        "setting": "contrast",
        "before": WORK / "phone-high-contrast-before.json",
        "enabled": WORK / "phone-high-contrast-enabled.json",
        "restored": WORK / "phone-high-contrast-restored.json",
        "labels": {},
    },
}
OUT = WORK / "stage-extra-native"
IPAD_UDID = "FA097340-7CDF-424F-A55C-42FF5C337B33"
DUO_UDID = "D1E42917-AF53-4D67-A382-CB6B87FC5A1D"
SCENES = {"Today": "T03", "Activity": "A01", "Wellness": "H01", "Life": "L01"}
PHONE_ACCESSIBILITY["phone-high-contrast"]["labels"] = {f"Water Lilies {style} {scene}": (style.lower(), screen) for style in ("Light", "Dark") for scene, screen in SCENES.items()}
SURFACES = ("Detail", "Sheet", "Workout")
LABEL = r"Water Lilies (?P<state>Light|Dark) (?P<surface>Detail|Sheet|Workout)"
IPAD_SCREEN = re.compile(rf"^screen-\d+-(?P<w>\d+)x(?P<h>\d+)-{LABEL}_\d+_(?P<id>[0-9A-Fa-f-]{{36}})\.png$")
IPAD_AX = re.compile(rf"^hierarchy-{LABEL}-[A-Za-z0-9_.]+_\d+_(?P<id>[0-9A-Fa-f-]{{36}})\.swift-\d+$")
IPAD_MAX_SCREEN = re.compile(r"^screen-\d+-(?P<w>\d+)x(?P<h>\d+)-Water Lilies MAX (?P<scene>Today|Activity|Wellness|Life)_\d+_(?P<id>[0-9A-Fa-f-]{36})\.png$")
IPAD_MAX_AX = re.compile(r"^hierarchy-Water Lilies MAX (?P<scene>Today|Activity|Wellness|Life)-[A-Za-z0-9_.]+_\d+_(?P<id>[0-9A-Fa-f-]{36})\.swift-\d+$")
WINDOW = re.compile(r"Window \(Main\).*?\{\{\s*[-\d.]+\s*,\s*[-\d.]+\s*\},\s*\{\s*([\d.]+)\s*,\s*([\d.]+)\s*\}\}")


def jload(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def png_size(path: Path) -> tuple[int, int]:
    with path.open("rb") as f:
        header = f.read(24)
    if len(header) != 24 or header[:8] != b"\x89PNG\r\n\x1a\n" or header[12:16] != b"IHDR":
        raise ValueError(f"invalid PNG/IHDR: {path}")
    return struct.unpack(">II", header[16:24])


def logical_viewport(path: Path) -> tuple[float, float]:
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        m = WINDOW.search(line)
        if m:
            return float(m.group(1)), float(m.group(2))
    raise ValueError(f"missing Window (Main) AX bounds: {path}")


def validate_ipad() -> tuple[dict, dict, dict]:
    proof = jload(IPAD_PROOF)
    receipt = jload(IPAD_RECEIPT)
    if proof.get("source_revision") != "2c8b55481214c5eda0375815d930cb84b1c2db35" or proof.get("source_worktree_dirty") is not False or proof.get("udid") != IPAD_UDID or proof.get("exit_code") != 0:
        raise ValueError("iPad source proof mismatch")
    if receipt.get("status") != "passed" or receipt.get("run_exit_status") != 0 or receipt.get("counts") != {"executed": 10, "passed": 10, "skipped": 0, "failed": 0}:
        raise ValueError("iPad UI receipt does not prove 10/10 passed")
    selectors = set(receipt.get("requested_selectors", []))
    max_selector = "DUNEUITests/ThemeMatrixUITests/testWaterLiliesMaximumAXRoots"
    flow_selector = "DUNEUITests/ThemeFlowMatrixUITests/testWaterLiliesFlows"
    if not {max_selector, flow_selector} <= selectors or not {max_selector, flow_selector} <= set(proof.get("selectors", [])):
        raise ValueError("iPad receipt/proof omits required Water Lilies selectors")

    manifest = jload(IPAD_EXPORT / "manifest.json")
    if not isinstance(manifest, list):
        raise ValueError("iPad manifest must be a list")
    selected: dict[str, dict] = {}
    for test in manifest:
        test_id = test.get("testIdentifier", "")
        if test_id not in ("ThemeMatrixUITests/testWaterLiliesMaximumAXRoots()", "ThemeFlowMatrixUITests/testWaterLiliesFlows()"):
            continue
        selector = max_selector if test_id.startswith("ThemeMatrix") else flow_selector
        paired: dict[str, dict] = {}
        for attachment in test.get("attachments", []):
            if attachment.get("isAssociatedWithFailure", False):
                continue
            original = attachment.get("suggestedHumanReadableName", "")
            png_m = IPAD_SCREEN.fullmatch(original) or IPAD_MAX_SCREEN.fullmatch(original)
            ax_m = IPAD_AX.fullmatch(original) or IPAD_MAX_AX.fullmatch(original)
            m = png_m or ax_m
            if not m:
                continue
            if png_m:
                if "scene" in png_m.groupdict():
                    category = "max"
                    scene = png_m.group("scene")
                    label_key = f"ipad/max/water-lilies/{SCENES[scene]}"
                else:
                    state = png_m.group("state").lower()
                    surface = png_m.group("surface").lower()
                    category = "flow"
                    label_key = f"ipad/flow/water-lilies/{state}/{surface}"
            else:
                if "scene" in ax_m.groupdict():
                    category = "max"
                    label_key = f"ipad/max/water-lilies/{SCENES[ax_m.group('scene')]}"
                else:
                    state = ax_m.group("state").lower()
                    surface = ax_m.group("surface").lower()
                    category = "flow"
                    label_key = f"ipad/flow/water-lilies/{state}/{surface}"
            if category == "flow":
                if selector != flow_selector:
                    raise ValueError("iPad flow image came from wrong selector")
            else:
                if selector != max_selector:
                    continue
            exported = attachment.get("exportedFileName")
            path = IPAD_EXPORT / str(exported or "")
            if not exported or not path.is_file() or attachment.get("deviceId") != IPAD_UDID:
                raise ValueError(f"iPad attachment missing or on wrong device: {original}")
            slot = paired.setdefault(label_key, {})
            if png_m:
                if "png" in slot:
                    raise ValueError(f"duplicate iPad PNG: {label_key}")
                slot["png"] = (attachment, path, (int(png_m.group("w")), int(png_m.group("h"))))
            else:
                if "ax" in slot:
                    raise ValueError(f"duplicate iPad AX: {label_key}")
                slot["ax"] = (attachment, path)

        for key, pair in paired.items():
            if set(pair) != {"png", "ax"}:
                raise ValueError(f"unpaired iPad PNG/AX: {key}")
            png, png_path, named_size = pair["png"]
            ax, ax_path = pair["ax"]
            uuid_re = re.compile(r"_\d+_([0-9A-Fa-f-]{36})(?:\.png|\.swift-\d+)$")
            png_uuid = uuid_re.search(png["suggestedHumanReadableName"])
            ax_uuid = uuid_re.search(ax["suggestedHumanReadableName"])
            if not png_uuid or not ax_uuid or png_uuid[1] != ax_uuid[1]:
                raise ValueError(f"iPad screenshot/AX activity mismatch: {key}")
            if abs(float(png["timestamp"]) - float(ax["timestamp"])) > 1 or png.get("deviceId") != ax.get("deviceId"):
                raise ValueError(f"iPad screenshot/AX metadata mismatch: {key}")
            actual = png_size(png_path)
            if actual != named_size:
                raise ValueError(f"iPad PNG IHDR mismatch: {key}")
            points = logical_viewport(ax_path)
            if any(abs(p / q - 2.0) > 0.04 for p, q in zip(actual, points)):
                raise ValueError(f"iPad PNG/AX pixel scale mismatch: {key}")
            expected = ("ipad", "flow") if "/flow/" in key else ("ipad", "max")
            record = {
                "key": key,
                "kind": expected[0],
                "category": expected[1],
                "test_identifier": selector,
                "attachment_name": png["suggestedHumanReadableName"],
                "ax_attachment_name": ax["suggestedHumanReadableName"],
                "timestamp": png["timestamp"],
                "timestamp_source": "xcresult-attachment-timestamp",
                "viewport_pixels": f"{actual[0]}x{actual[1]} px",
                "logical_viewport_points": f"{points[0]}x{points[1]} pt",
                "device": {"kind": "ipad", "platform": "iOS Simulator", "model_name": "iPad mini (A20 Pro)", "identifier": IPAD_UDID},
                "source_revision": proof["source_revision"],
                "source_worktree_dirty": False,
                "source_worktree": None,
                "source_manifest": str((IPAD_EXPORT / "manifest.json").resolve()),
                "source_proof": str(IPAD_PROOF.resolve()),
                "source_receipt": str(IPAD_RECEIPT.resolve()),
                "source_png": str(png_path.resolve()),
                "source_ax": str(ax_path.resolve()),
                "sha256_png": digest(png_path),
                "sha256_ax": digest(ax_path),
                "native_size": list(actual),
                "window_size_pt": list(points),
                "actual_angle": None,
                "_png": png_path,
                "_ax": ax_path,
            }
            if key in selected:
                raise ValueError(f"duplicate iPad key: {key}")
            selected[key] = record
    expected_keys = {f"ipad/flow/water-lilies/{style}/{surface}" for style in ("light", "dark") for surface in ("detail", "sheet", "workout")}
    expected_keys |= {f"ipad/max/water-lilies/{screen}" for screen in SCENES.values()}
    if set(selected) != expected_keys:
        raise ValueError(f"iPad extras expected10; found{len(selected)} missing={sorted(expected_keys-set(selected))}")
    metadata = {p.name: {"path": str(p.resolve()), "sha256": digest(p)} for p in (IPAD_PROOF, IPAD_RECEIPT, IPAD_EXPORT / "manifest.json")}
    return selected, {"source_revision": proof["source_revision"], "source_worktree_dirty": False, "device": {"kind": "ipad", "platform": "iOS Simulator", "model_name": "iPad mini (A20 Pro)", "identifier": IPAD_UDID}, "evidence": metadata}, {"log": receipt.get("log_path"), "receipt": receipt}


def validate_duo() -> tuple[dict, dict, dict]:
    batch = DUO_BATCH.resolve()
    preflight_path, receipt_path, runner_path, pairs_path = (batch / n for n in ("preflight.json", "ui.log.result.json", "runner-result.json", "pairs.json"))
    pose_path, orient_path, display_path = (batch / n for n in ("pose-post-test.json", "orientation-post-test.json", "displays-post-test.json"))
    preflight, receipt, runner = jload(preflight_path), jload(receipt_path), jload(runner_path)
    if preflight.get("source_revision") != "861865174f7b5dad36a5492e7ac5b8334111285e" or preflight.get("source_worktree_dirty") is not False or preflight.get("device") != DUO_UDID or preflight.get("pose") != "closed":
        raise ValueError("Duo source proof mismatch")
    if receipt.get("status") != "passed" or receipt.get("run_exit_status") != 0 or receipt.get("counts") != {"executed": 2, "passed": 2, "skipped": 0, "failed": 0} or runner.get("returncode") != 0:
        raise ValueError("Duo UI receipt does not prove 2/2 passed and runner exit 0")
    selectors = set(receipt.get("requested_selectors", []))
    required = {"DUNEUITests/ThemeMatrixUITests/testWaterLiliesMaximumAXRoots", "DUNEUITests/ThemeFlowMatrixUITests/testWaterLiliesFlows"}
    if selectors != required or set(preflight.get("selectors", [])) != required:
        raise ValueError("Duo receipt/preflight selectors do not match the two intended cases")
    pose = jload(pose_path)
    orientation, displays = jload(orient_path), jload(display_path)
    orient_udid = orientation.get("result", {}).get("deviceIdentifier")
    if pose.get("pose") != "closed" or pose.get("stage") != "post-test" or pose.get("active_display") != "LCD" or pose.get("actual_angle") is not None or pose.get("orientation") != "portrait":
        raise ValueError("Duo post-test physical pose does not match requested closed pose")
    active = [d for d in displays.get("result", {}).get("displays", []) if d.get("active") is True]
    if len(active) != 1 or active[0].get("name") != "LCD" or active[0].get("backlightState") != "activeOn" or active[0].get("nativeSize") != [1398, 2034]:
        raise ValueError("Duo post-test active display is not the closed LCD")
    if orientation.get("result", {}).get("deviceOrientation") != "portrait" or orient_udid != DUO_UDID:
        raise ValueError("Duo orientation/device readback mismatch")
    rows = jload(pairs_path)
    if runner.get("checkpoints_attempted") != len(rows):
        raise ValueError("Duo checkpoint list/runner count mismatch")
    selected = {}
    action_re = re.compile(r"^DUNE_VISUAL_AUDIT_READY Water Lilies (?P<label>(?:Light|Dark) (?:Detail|Sheet|Workout)|MAX (?:Today|Activity|Wellness|Life)) \[[^\]]+\] DEADLINE=[^\s]+$")
    for row in rows:
        if row.get("canonical_theme_capture") is not True:
            continue
        action = row.get("action", "")
        m = action_re.fullmatch(action)
        if not m:
            raise ValueError(f"Duo canonical action unrecognized: {action}")
        label = m.group("label")
        selector = next((s for s in required if ("Flows" in s and label.endswith(("Detail", "Sheet", "Workout"))) or ("MaximumAXRoots" in s and label.startswith("MAX "))), None)
        if not selector:
            raise ValueError(f"Duo extras action lacks selector mapping: {action}")
        if row.get("active_display") != "LCD" or tuple(row.get("active_png_dimensions", [])) != (1398, 2034) or tuple(row.get("ax_viewport", [])) != (466.0, 678.0):
            raise ValueError("Duo pair metadata does not match physical closed display")
        original_png, original_ax = row["active_png"], row["ax"]
        # This batch was copied into the active worktree with its original
        # absolute provenance paths intact. Resolve bytes by basename only
        # inside the already validated, exact batch directory.
        png = (batch / Path(original_png).name).resolve()
        ax = (batch / Path(original_ax).name).resolve()
        if not png.is_relative_to(batch) or not ax.is_relative_to(batch) or not png.is_file() or not ax.is_file():
            raise ValueError("Duo native evidence path escaped or is missing")
        if png.name not in [Path(p).name for p in row.get("paired_pngs", [])]:
            raise ValueError("Duo selected PNG is not a declared paired display capture")
        actual = png_size(png)
        points = logical_viewport(ax)
        if actual != (1398, 2034) or tuple(row.get("active_png_dimensions", [])) != actual or points != (466.0, 678.0):
            raise ValueError("Duo PNG/AX physical viewport mismatch")
        if any(abs(px / pt - 3.0) > 0.05 for px, pt in zip(actual, points)):
            raise ValueError("Duo PNG/AX scale is not approximately 3x")
        if label.startswith("MAX "):
            scene = label.removeprefix("MAX ")
            key = f"duo-closed/max/water-lilies/{SCENES[scene]}"
            category = "max"
        else:
            style, surface = label.split(" ", 1)
            key = f"duo-closed/flow/water-lilies/{style.lower()}/{surface.lower()}"
            category = "flow"
        if key in selected:
            raise ValueError(f"duplicate Duo canonical extra: {key}")
        selector_label = "DUNEUITests/ThemeMatrixUITests/testWaterLiliesMaximumAXRoots" if category == "max" else "DUNEUITests/ThemeFlowMatrixUITests/testWaterLiliesFlows"
        if selector != selector_label:
            raise ValueError(f"Duo action mapped to wrong selector: {key}")
        timestamp = png.stat().st_mtime
        selected[key] = {
            "key": key,
            "kind": "duo-closed",
            "category": category,
            "test_identifier": selector,
            "attachment_name": action,
            "ax_attachment_name": ax.name,
            "timestamp": timestamp,
            "timestamp_source": "host-original-file-mtime",
            "device": {"kind": "duo", "platform": "iOS Simulator", "model_name": "iPhone Duo", "identifier": DUO_UDID},
            "device_id": DUO_UDID,
            "source_revision": preflight["source_revision"],
            "source_worktree_dirty": False,
            "source_worktree": None,
            "pose": "closed",
            "active_display": "LCD",
            "orientation": "portrait",
            "actual_angle": None,
            "viewport_pixels": "1398x2034 px",
            "logical_viewport_points": "466x678 pt",
            "native_size": [1398, 2034],
            "window_size_pt": [466, 678],
            "pair_sequence": row["sequence"],
            "source_batch": str(batch),
            "source_png": str(png),
            "source_ax": str(ax),
            "recorded_source_png": original_png,
            "recorded_source_ax": original_ax,
            "sha256_png": digest(png),
            "sha256_ax": digest(ax),
            "_png": png,
            "_ax": ax,
        }
    expected = {f"duo-closed/flow/water-lilies/{s}/{x}" for s in ("light", "dark") for x in ("detail", "sheet", "workout")}
    expected |= {f"duo-closed/max/water-lilies/{s}" for s in SCENES.values()}
    if set(selected) != expected:
        raise ValueError(f"Duo extras expected10; found{len(selected)} missing={sorted(expected-set(selected))}")
    evidence = {}
    for p in (preflight_path, receipt_path, runner_path, pairs_path, pose_path, orient_path, display_path):
        evidence[p.name] = {"path": str(p.resolve()), "sha256": digest(p)}
    metadata = {"source_revision": preflight["source_revision"], "source_worktree_dirty": False,
                "device": {"kind": "duo", "platform": "iOS Simulator", "model_name": "iPhone Duo", "identifier": DUO_UDID},
                "pose": "closed", "active_display": "LCD", "orientation": "portrait", "actual_angle": None,
                "evidence": evidence}
    return selected, metadata, {"receipt": receipt, "runner": runner}


def validate_phone_accessibility() -> tuple[dict, dict]:
    selected, groups = {}, {}
    udid = "9D0602F1-9D0B-4AB0-B144-666748CCDC19"
    for stem, config in PHONE_ACCESSIBILITY.items():
        proof, receipt = jload(config["proof"]), jload(config["receipt"])
        selector = config["selector"]
        if proof.get("source_revision") != "c506471991790259dc46b3033bd1a3e589ea71f7" or proof.get("source_worktree_dirty") is not False or proof.get("udid") != udid or proof.get("exit_code") != 0:
            raise ValueError(f"{stem} source proof mismatch")
        if receipt.get("status") != "passed" or receipt.get("run_exit_status") != 0 or receipt.get("counts") != {"executed": 1, "passed": 1, "skipped": 0, "failed": 0} or receipt.get("requested_selectors") != [selector]:
            raise ValueError(f"{stem} does not prove its selector passed")
        if proof.get("selectors") != [selector] or proof.get("setting") != config["setting"]:
            raise ValueError(f"{stem} selector/setting proof mismatch")
        before, enabled, restored = (jload(config[k]) for k in ("before", "enabled", "restored"))
        if config["setting"] == "voiceover":
            values = [x.get("result", {}).get("enabled") for x in (before, enabled, restored)]
            ids = [x.get("result", {}).get("deviceIdentifier") for x in (before, enabled, restored)]
            good = values == [False, True, False] and ids == [udid] * 3
        else:
            values = [x.get("increase_contrast") for x in (before, enabled, restored)]
            ids = [x.get("udid") for x in (before, enabled, restored)]
            good = values == ["disabled", "enabled", "disabled"] and ids == [udid] * 3
        if not good or proof.get("original_setting") is not False or proof.get("restored_setting") is not False:
            raise ValueError(f"{stem} setting enable/restore readback mismatch")

        export = WORK / "exports" / stem
        manifest = jload(export / "manifest.json")
        match = []
        for test in manifest:
            if not test.get("testIdentifier", "").startswith(selector.split("/")[1].split("test")[0]):
                continue
            for attachment in test.get("attachments", []):
                if attachment.get("isAssociatedWithFailure", False):
                    continue
                original = attachment.get("suggestedHumanReadableName", "")
                suffix = next((label for label in config["labels"] if original.startswith(("screen-0-1206x2622-" + label, "hierarchy-" + label))), None)
                if suffix:
                    match.append((suffix, attachment, original.startswith("screen-")))
        # Only the 11 selected named semantic states are accepted.
        if len(match) != len(config["labels"]) * 2:
            raise ValueError(f"{stem} expected {len(config['labels'])} named PNG/AX attachments, got {len(match)}")
        per_key = {}
        for label, attachment, is_png in match:
            key_id = re.search(r"_\d+_([0-9A-Fa-f-]{36})(?:\.png|\.swift-\d+)$", attachment.get("suggestedHumanReadableName", ""))
            if not key_id or attachment.get("deviceId") != udid:
                raise ValueError(f"{stem} attachment activity/device mismatch")
            slot = per_key.setdefault((label, key_id[1]), {})
            kind = "png" if is_png else "ax"
            if kind in slot:
                raise ValueError(f"{stem} duplicate attachment {label}")
            exported = attachment.get("exportedFileName")
            path = export / str(exported or "")
            if not exported or not path.is_file():
                raise ValueError(f"{stem} missing exported attachment bytes")
            slot[kind] = (attachment, path)
        for (label, activity), pair in per_key.items():
            if set(pair) != {"png", "ax"}:
                raise ValueError(f"{stem} unmatched PNG/AX pair {label}")
            png, png_path = pair["png"]
            ax, ax_path = pair["ax"]
            if abs(float(png["timestamp"]) - float(ax["timestamp"])) > 0.01 or png.get("deviceId") != ax.get("deviceId"):
                raise ValueError(f"{stem} pair timestamp/device mismatch {label}")
            actual = png_size(png_path)
            named = re.match(r"^screen-\d+-(\d+)x(\d+)-", png["suggestedHumanReadableName"])
            if not named or actual != (int(named[1]), int(named[2])) or actual != (1206, 2622):
                raise ValueError(f"{stem} PNG dimensions mismatch {label}")
            points = logical_viewport(ax_path)
            if points != (402.0, 874.0) or any(abs(px / pt - 3.0) > 0.05 for px, pt in zip(actual, points)):
                raise ValueError(f"{stem} PNG/AX viewport mismatch {label}")
            scene = config["labels"][label]
            if stem == "phone-voiceover-fixed":
                theme_key = {"T03": "today-root", "CONDITION_DETAIL": "condition-detail", "T03_RETURNED": "today-returned"}[scene]
                key = f"phone/voiceover/water-lilies/{theme_key}"
                category, display_scene = "voiceover", scene
            else:
                style, screen = scene
                key = f"phone/high-contrast/water-lilies/{style}/{screen}"
                category, display_scene = "high-contrast", screen
            if key in selected:
                raise ValueError(f"duplicate phone accessibility key: {key}")
            selected[key] = {
                "key": key, "kind": "phone", "category": category, "screen_id": display_scene,
                "test_identifier": selector, "attachment_name": png["suggestedHumanReadableName"],
                "ax_attachment_name": ax["suggestedHumanReadableName"], "timestamp": png["timestamp"],
                "timestamp_source": "xcresult-attachment-timestamp",
                "device": {"kind": "iphone", "platform": "iOS Simulator", "model_name": "iPhone 17 Pro", "identifier": udid},
                "device_id": udid, "source_revision": proof["source_revision"], "source_worktree_dirty": False,
                "source_worktree": None, "source_manifest": str((export / "manifest.json").resolve()),
                "source_proof": str(config["proof"].resolve()), "source_receipt": str(config["receipt"].resolve()),
                "setting_evidence": {k: {"path": str(config[k].resolve()), "sha256": digest(config[k])} for k in ("before", "enabled", "restored")},
                "original_source_png": png["suggestedHumanReadableName"], "original_source_ax": ax["suggestedHumanReadableName"],
                "source_png": str(png_path.resolve()), "source_ax": str(ax_path.resolve()),
                "sha256_png": digest(png_path), "sha256_ax": digest(ax_path),
                "viewport_pixels": f"{actual[0]}x{actual[1]} px", "logical_viewport_points": f"{points[0]}x{points[1]} pt",
                "native_size": list(actual), "window_size_pt": list(points), "actual_angle": None,
                "_png": png_path, "_ax": ax_path,
            }
        groups[stem] = {"capture_count": len(config["labels"]), "source_revision": proof["source_revision"], "source_worktree_dirty": False, "device": {"kind": "iphone", "platform": "iOS Simulator", "model_name": "iPhone 17 Pro", "identifier": udid}, "setting": config["setting"], "setting_evidence": {k: {"path": str(config[k].resolve()), "sha256": digest(config[k])} for k in ("before", "enabled", "restored")}, "source_proof": {"path": str(config["proof"].resolve()), "sha256": digest(config["proof"])}, "source_receipt": {"path": str(config["receipt"].resolve()), "sha256": digest(config["receipt"])}, "source_manifest": {"path": str((export / "manifest.json").resolve()), "sha256": digest(export / "manifest.json")}}
    if len(selected) != 11:
        raise ValueError(f"expected 11 phone accessibility captures, found {len(selected)}")
    return selected, groups


def stage() -> None:
    if OUT.exists():
        raise ValueError(f"refusing to overwrite existing stage: {OUT}")
    ipad, ipad_meta, ipad_result = validate_ipad()
    duo, duo_meta, duo_result = validate_duo()
    phone, phone_groups = validate_phone_accessibility()
    entries = {**ipad, **duo, **phone}
    if len(entries) != 31:
        raise ValueError(f"expected 31 unique extra captures, found {len(entries)}")
    OUT.mkdir(parents=True)
    try:
        sections = []
        for key, record in sorted(entries.items()):
            item = dict(record)
            png, ax = item.pop("_png"), item.pop("_ax")
            relative_png = f"images/{key}.png"
            relative_ax = f"ax/{key}.txt"
            for source, rel, hash_key in ((png, relative_png, "sha256_png"), (ax, relative_ax, "sha256_ax")):
                target = OUT / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, target)
                if digest(target) != item[hash_key]:
                    raise ValueError(f"stage copy SHA-256 mismatch: {key} {rel}")
            item["file"] = relative_png
            item["ax_file"] = relative_ax
            item["source_worktree"] = item.get("source_worktree")
            entries[key] = item
            title = key.split("/")
            sections.append(f'<article><h3>{html.escape(" · ".join(title))}</h3><p>{html.escape(item["test_identifier"])}</p><img src="{html.escape(relative_png)}" alt="{html.escape(item["attachment_name"])}"><p><a href="{html.escape(relative_ax)}">AX hierarchy</a></p></article>')
        payload = {
            "schema_version": 1,
            "stage_kind": "native-theme-extras",
            "capture_count": 31,
            "groups": {"ipad": {"capture_count": 10, **ipad_meta}, "duo-closed": {"capture_count": 10, **duo_meta}, **phone_groups},
            "captures": entries,
        }
        (OUT / "provenance.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        (OUT / "gallery.html").write_text("<!doctype html><html><meta charset=utf-8><title>Native Water Lilies extras</title><style>body{font:15px system-ui;background:#151918;color:#eee;margin:24px}main{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px}article{background:#242a27;padding:14px;border-radius:10px}img{width:100%;height:420px;object-fit:contain;background:#111}</style><h1>Water Lilies · Native extras</h1><p>Passed iPad, closed Duo, VoiceOver, and High Contrast captures. Source, setting state, timestamps, viewport metadata, and hashes are in provenance.json.</p><main>" + "\n".join(sections) + "</main></html>\n", encoding="utf-8")
    except BaseException:
        shutil.rmtree(OUT, ignore_errors=True)
        raise
    print(f"Staged {len(entries)} PNG+AX pairs at {OUT}; no tracked files were changed.")


if __name__ == "__main__":
    try:
        stage()
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        raise SystemExit(2)
