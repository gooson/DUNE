#!/usr/bin/env python3
"""Validate Duo native active-display PNG/AX pairs and stage an 8-theme matrix.

Use --check-only to validate a partial completed batch without creating a
stage. A full stage is written only after all 64 canonical roots are present.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import shutil
import struct
import sys


ROOT = Path(__file__).resolve().parents[2]
THEMES = {
    "Desert": ("dune", "testDesertWarmMatrix"),
    "Ocean": ("ocean", "testOceanCoolMatrix"),
    "Forest": ("forest", "testForestGreenMatrix"),
    "Sakura": ("sakura", "testSakuraCalmMatrix"),
    "Arctic": ("arctic", "testArcticDawnMatrix"),
    "Solar": ("solar", "testSolarPopMatrix"),
    "Contour": ("contour", "testContourAtlasMatrix"),
    "Water Lilies": ("water-lilies", "testWaterLiliesMatrix"),
}
SCREENS = {"Today": "T03", "Activity": "A01", "Wellness": "H01", "Life": "L01"}
ROOT_ACTION = re.compile(
    r"^DUNE_VISUAL_AUDIT_READY (?P<label>(?:Desert|Ocean|Forest|Sakura|Arctic|Solar|Contour|Water Lilies) "
    r"(?:Light|Dark) (?:Today|Activity|Wellness|Life)) \[(?P<source>[^\]]+)\] DEADLINE=[^\s]+$"
)
WINDOW_BOUNDS = re.compile(
    r"Window \(Main\).*?\{\{\s*(-?[\d.]+)\s*,\s*(-?[\d.]+)\s*\},\s*\{\s*([\d.]+)\s*,\s*([\d.]+)\s*\}\}"
)


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as stream:
        header = stream.read(24)
    if len(header) != 24 or header[:8] != b"\x89PNG\r\n\x1a\n" or header[12:16] != b"IHDR":
        raise ValueError(f"invalid PNG/IHDR: {path}")
    width, height = struct.unpack(">II", header[16:24])
    if width <= 0 or height <= 0:
        raise ValueError(f"invalid PNG dimensions: {path}")
    return width, height


def mapping_from_source(action: str) -> tuple[str, str, str] | None:
    match = ROOT_ACTION.fullmatch(action)
    if not match:
        return None
    theme_name, appearance, screen_name = match.group("label").rsplit(" ", 2)
    theme_id, selector_suffix = THEMES[theme_name]
    selector = f"DUNEUITests/ThemeMatrixUITests/{selector_suffix}"
    return f"{theme_id}/{appearance.lower()}/{SCREENS[screen_name]}", selector, match.group("source")


def resolve_inside(root: Path, value: str, label: str) -> Path:
    path = Path(value)
    if not path.is_absolute():
        path = root / path
    resolved = path.resolve()
    if not resolved.is_relative_to(root.resolve()):
        raise ValueError(f"{label} escapes batch directory: {value}")
    if not resolved.is_file():
        raise ValueError(f"{label} file missing: {resolved}")
    return resolved


def load_source_provenance(batch: Path, explicit_revision: str | None,
                           expected_udid: str, requested_pose: str) -> tuple[str, dict]:
    candidates = []
    for name in ("preflight.json", "validated-existing-evidence.json"):
        path = batch / name
        if path.is_file():
            value = read_json(path)
            if isinstance(value, dict):
                candidates.append((path, value))
    if not candidates:
        raise ValueError(f"no preflight or validated-existing-evidence.json in {batch}")
    revisions = {item.get("source_revision") for _, item in candidates if item.get("source_revision")}
    dirty_values = {item.get("source_worktree_dirty") for _, item in candidates
                    if "source_worktree_dirty" in item}
    if len(revisions) > 1 or len(dirty_values) > 1:
        raise ValueError(f"conflicting batch source provenance in {batch}")
    revision = next(iter(revisions), None)
    if revision and explicit_revision and revision != explicit_revision:
        raise ValueError(f"explicit source revision conflicts with batch provenance in {batch}")
    revision = revision or explicit_revision
    if not isinstance(revision, str) or not revision:
        raise ValueError(f"source revision missing in {batch}; supply --source-revision")
    if dirty_values != {False}:
        raise ValueError(f"batch must have authoritative source_worktree_dirty=false in {batch}")
    for path, item in candidates:
        item_udid = item.get("udid", item.get("device"))
        if item_udid and item_udid != expected_udid:
            raise ValueError(f"batch source evidence device UDID disagrees: {path}")
        if item.get("pose") and item.get("pose") != requested_pose:
            raise ValueError(f"batch source evidence pose disagrees: {path}")
    return revision, {
        "files": [{"path": str(path.resolve()), "sha256": sha256(path)} for path, _ in candidates],
        "source_worktree_dirty": False,
    }


def validate_batch(batch: Path, requested_pose: str, explicit_revision: str | None) -> dict:
    batch = batch.resolve()
    pairs_path = batch / "pairs.json"
    receipt_path = batch / "ui.log.result.json"
    runner_path = batch / "runner-result.json"
    pose_path = batch / "physicalpose-post-test.json"
    if not pose_path.exists():
        pose_path = batch / "pose-post-test.json"
    orientation_path = batch / "orientation-post-test.json"
    displays_path = batch / "displays-post-test.json"
    required = (pairs_path, receipt_path, runner_path, pose_path, orientation_path, displays_path)
    if any(not path.is_file() for path in required):
        missing = [str(path.name) for path in required if not path.is_file()]
        raise ValueError(f"batch missing required evidence {missing}: {batch}")

    receipt = read_json(receipt_path)
    if receipt.get("status") != "passed" or receipt.get("run_exit_status") != 0:
        raise ValueError(f"UI result receipt is not passed/exit 0: {batch}")
    counts = receipt.get("counts", {})
    if counts.get("failed") != 0 or counts.get("skipped") != 0 or counts.get("executed") != counts.get("passed"):
        raise ValueError(f"UI result receipt has failed/skipped/missing cases: {batch}")
    runner = read_json(runner_path)
    if runner.get("returncode") != 0:
        raise ValueError(f"runner result is not exit 0: {batch}")
    pose_data = read_json(pose_path)
    orientation_data = read_json(orientation_path)
    displays_data = read_json(displays_path)
    if pose_data.get("pose") != requested_pose or pose_data.get("stage") != "post-test":
        raise ValueError(f"post-test physical pose does not match {requested_pose}: {batch}")
    active_display = pose_data.get("active_display")
    orientation = pose_data.get("orientation")
    if not active_display or not orientation:
        raise ValueError(f"post-test active display/orientation missing: {batch}")
    orientation_result = orientation_data.get("result", {})
    orientation_udid = orientation_result.get("deviceIdentifier")
    if orientation_result.get("deviceOrientation") != orientation:
        raise ValueError(f"post-test orientation readback disagrees with physical pose: {batch}")
    display_result = displays_data.get("result", {})
    display_list = display_result.get("displays", [])
    active_displays = [display for display in display_list if display.get("active") is True]
    if len(active_displays) != 1:
        raise ValueError(f"expected exactly one active physical display: {batch}")
    active = active_displays[0]
    native_size = active.get("nativeSize")
    if active.get("name") != active_display or active.get("backlightState") != "activeOn" or not isinstance(native_size, list):
        raise ValueError(f"post-test display readback disagrees with active panel: {batch}")
    if pose_data.get("active_native_size") != native_size:
        raise ValueError(f"post-test native display size disagrees with pose record: {batch}")
    if display_result.get("orientation", {}).get("currentDeviceOrientation") != orientation:
        raise ValueError(f"post-test display and orientation report different device orientations: {batch}")
    display_arguments = displays_data.get("info", {}).get("arguments", [])
    try:
        display_udid = display_arguments[display_arguments.index("--device") + 1]
    except (ValueError, IndexError):
        raise ValueError(f"display readback has no target device identifier: {batch}")
    if orientation_udid != display_udid:
        raise ValueError(f"orientation and display readbacks identify different devices: {batch}")
    udid = orientation_udid
    if not isinstance(udid, str) or not udid:
        raise ValueError(f"post-test device UDID missing: {batch}")
    revision, source_record = load_source_provenance(batch, explicit_revision, udid, requested_pose)

    rows = read_json(pairs_path)
    if not isinstance(rows, list):
        raise ValueError(f"pairs.json must be a list: {batch}")
    if runner.get("checkpoints_attempted") is not None and runner.get("checkpoints_attempted") != len(rows):
        raise ValueError(f"pairs.json row count does not match runner checkpoint count: {batch}")
    selectors_in_receipt = set(receipt.get("requested_selectors", []))
    if len(selectors_in_receipt) != counts.get("executed"):
        raise ValueError(f"passed receipt selector count does not match executed test count: {batch}")
    canonical = {}
    for row in rows:
        if not isinstance(row, dict) or row.get("canonical_theme_capture") is not True:
            continue
        parsed = mapping_from_source(row.get("action", ""))
        if parsed is None:
            raise ValueError(f"canonical pair has a malformed root action: {row.get('action')!r}")
        key, selector, source_location = parsed
        if selector not in selectors_in_receipt:
            raise ValueError(f"root action lacks its exact passed selector in receipt: {selector}")
        if row.get("active_display") != active_display:
            raise ValueError(f"canonical root came from inactive/wrong panel: {key}")
        png = resolve_inside(batch, row.get("active_png", ""), "active PNG")
        ax = resolve_inside(batch, row.get("ax", ""), "AX hierarchy")
        if png not in [resolve_inside(batch, item, "paired PNG") for item in row.get("paired_pngs", [])]:
            raise ValueError(f"selected active PNG is not a declared pair member: {key}")
        dimensions = png_dimensions(png)
        if dimensions != tuple(row.get("active_png_dimensions", [])) or dimensions != tuple(native_size):
            raise ValueError(f"active PNG IHDR does not match pair/post-test display dimensions: {key}")
        bounds = None
        for line in ax.read_text(encoding="utf-8", errors="replace").splitlines():
            match = WINDOW_BOUNDS.search(line)
            if match:
                bounds = tuple(float(match.group(i)) for i in range(1, 5))
                break
        if bounds is None:
            raise ValueError(f"AX hierarchy has no parseable Window (Main) viewport: {key}")
        point_size = (bounds[2], bounds[3])
        ax_viewport = tuple(float(value) for value in row.get("ax_viewport", []))
        if len(ax_viewport) != 2 or any(abs(a - b) > 0.05 for a, b in zip(point_size, ax_viewport)):
            raise ValueError(f"AX bounds disagree with pair metadata: {key}")
        scales = (dimensions[0] / point_size[0], dimensions[1] / point_size[1])
        if any(abs(scale - 3.0) > 0.05 for scale in scales):
            raise ValueError(f"active PNG to AX viewport scale is not approximately 3x: {key}: {scales}")
        try:
            host_mtime = png.stat().st_mtime
        except OSError as error:
            raise ValueError(f"cannot stat active PNG original file: {png}") from error
        if not math.isfinite(host_mtime):
            raise ValueError(f"invalid active PNG host mtime: {png}")
        if key in canonical:
            raise ValueError(f"duplicate canonical root within batch: {key}")
        theme_id, appearance, screen_id = key.split("/")
        theme_name = next(name for name, (identifier, _) in THEMES.items() if identifier == theme_id)
        capture = {
            "theme": theme_id,
            "appearance": appearance,
            "screen_id": screen_id,
            "file": f"images/{key}.png",
            "ax_file": f"ax/{key}.txt",
            "attachment_name": row["action"],
            "ax_attachment_name": ax.name,
            "test_identifier": selector,
            "test_source_location": source_location,
            "timestamp": host_mtime,
            "timestamp_source": "host-original-file-mtime",
            "device": {"kind": "duo-open" if requested_pose == "open" else "duo",
                       "platform": "iOS Simulator", "model_name": "iPhone Duo", "identifier": udid},
            "device_id": udid,
            "source_revision": revision,
            "source_worktree_dirty": False,
            "pose": requested_pose,
            "active_display": active_display,
            "orientation": orientation,
            "actual_angle": None,
            "viewport_pixels": f"{dimensions[0]}x{dimensions[1]} px",
            "logical_viewport_points": f"{point_size[0]}x{point_size[1]} pt",
            "native_size": list(dimensions),
            "window_size_pt": list(point_size),
            "pixel_scales": list(scales),
            "pair_sequence": row.get("sequence"),
            "checkpoint": row.get("checkpoint"),
            "source_png": str(png),
            "source_ax": str(ax),
            "source_batch": str(batch),
            "sha256_png": sha256(png),
            "sha256_ax": sha256(ax),
        }
        canonical[key] = {"record": capture, "png_source": png, "ax_source": ax}

    if not canonical:
        raise ValueError(f"batch has no canonical root captures: {batch}")
    selectors = {capture["record"]["test_identifier"] for capture in canonical.values()}
    if len(selectors) * 8 != len(canonical):
        raise ValueError(f"canonical roots must contain exactly 8 captures per matrix selector in {batch}")
    metadata_paths = [receipt_path, runner_path, pose_path, orientation_path, displays_path, pairs_path]
    metadata_paths.extend(Path(item["path"]) for item in source_record["files"])
    batch_record = {
        "path": str(batch),
        "pose": requested_pose,
        "udid": udid,
        "source_revision": revision,
        "source_worktree_dirty": False,
        "ui_status": receipt["status"],
        "ui_counts": counts,
        "runner_returncode": runner["returncode"],
        "canonical_capture_count": len(canonical),
        "active_display": active_display,
        "orientation": orientation,
        "actual_angle": pose_data.get("actual_angle"),
        "evidence_files": {path.name: {"path": str(path.resolve()), "sha256": sha256(path)} for path in metadata_paths},
    }
    return {"captures": canonical, "batch": batch_record, "device_id": udid,
            "source_revision": revision, "active_display": active_display,
            "orientation": orientation, "native_size": tuple(native_size),
            "logical_viewport": next(iter({item["record"]["logical_viewport_points"] for item in canonical.values()})),
            "source_provenance": source_record}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batch", action="append", required=True, type=Path,
                        help="completed pose batch directory; repeat for each validated batch")
    parser.add_argument("--pose", required=True, choices=("closed", "open"))
    parser.add_argument("--source-revision", help="explicit fallback/confirmation for source revision provenance")
    parser.add_argument("--source-worktree", type=Path, default=ROOT,
                        help="source worktree path recorded in stage (defaults to this workspace)")
    parser.add_argument("--check-only", action="store_true", help="validate partial evidence without copying files or claiming complete stage")
    parser.add_argument("--output", type=Path, help="new ignored stage path; defaults to stage-duo-<pose>")
    args = parser.parse_args()
    output = args.output or ROOT / f".codex-checks/theme-overhaul/stage-duo-{args.pose}"
    if not args.check_only and len({path.resolve() for path in args.batch}) < 2:
        parser.error("a complete Duo stage requires at least two distinct validated batch directories")
    if not args.check_only and output.exists():
        parser.error(f"output must be a new stage directory: {output}")
    if not args.check_only and not output.resolve().is_relative_to((ROOT / ".codex-checks").resolve()):
        parser.error("stage output must remain under this workspace's ignored .codex-checks directory")

    batches = [validate_batch(path, args.pose, args.source_revision) for path in args.batch]
    identities = {(batch["device_id"], batch["source_revision"], batch["active_display"],
                   batch["orientation"], batch["native_size"], batch["logical_viewport"])
                  for batch in batches}
    if len(identities) != 1:
        raise ValueError("batches must share one device UID, source revision, pose panel, orientation, and viewport")
    device_id, revision, active_display, orientation, native_size, logical_viewport = next(iter(identities))
    captures = {}
    batch_records = []
    for batch in batches:
        batch_records.append(batch["batch"])
        for key, capture in batch["captures"].items():
            if key in captures:
                raise ValueError(f"duplicate root across batches: {key}")
            captures[key] = capture

    expected = {f"{theme}/{appearance}/{screen}" for theme, _ in THEMES.values()
                for appearance in ("light", "dark") for screen in SCREENS.values()}
    missing, extra = sorted(expected - set(captures)), sorted(set(captures) - expected)
    if args.check_only:
        print(f"Validated {len(captures)} Duo {args.pose} canonical roots across {len(batches)} batches; stage incomplete: missing={len(missing)}, unknown={len(extra)}")
        print(f"Device {device_id}; source {revision}; active panel {active_display}, {orientation}; native {native_size}, AX {logical_viewport}")
        return 0
    if missing or extra or len(captures) != 64:
        raise ValueError(f"complete Duo pose requires exactly 64 roots; missing={missing}, unknown={extra}")

    device = {"kind": "duo-open" if args.pose == "open" else "duo",
              "platform": "iOS Simulator", "model_name": "iPhone Duo", "identifier": device_id}
    output.mkdir(parents=True)
    try:
        records = {}
        for key, capture in sorted(captures.items()):
            record = dict(capture["record"])
            record["device"] = device
            record["source_worktree"] = str(args.source_worktree.resolve())
            records[key] = record
            for source, relative, expected_hash in (
                (capture["png_source"], record["file"], record["sha256_png"]),
                (capture["ax_source"], record["ax_file"], record["sha256_ax"]),
            ):
                destination = output / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, destination)
                if sha256(destination) != expected_hash:
                    raise ValueError(f"staged copy hash mismatch: {destination}")
        provenance = {
            "schema_version": 1,
            "device": device,
            "pose": args.pose,
            "active_display": active_display,
            "orientation": orientation,
            "actual_angle": None,
            "native_size": list(native_size),
            "source_revision": revision,
            "source_worktree": str(args.source_worktree.resolve()),
            "source_worktree_dirty": False,
            "viewport_pixels": f"{native_size[0]}x{native_size[1]} px",
            "logical_viewport_points": logical_viewport,
            "batches": batch_records,
            "captures": records,
        }
        (output / "provenance.json").write_text(json.dumps(provenance, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    except BaseException:
        shutil.rmtree(output, ignore_errors=True)
        raise
    print(f"Staged complete {len(records)} Duo {args.pose} PNG+AX pairs at {output}")
    print(f"Device {device_id}; source {revision}; active panel {active_display}, {orientation}; native {native_size}, AX {logical_viewport}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as error:
        print(f"error: {error}", file=sys.stderr)
        raise SystemExit(2)
