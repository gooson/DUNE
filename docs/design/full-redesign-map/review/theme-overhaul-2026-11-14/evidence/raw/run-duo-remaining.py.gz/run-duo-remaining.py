import pathlib,subprocess,json,time,sys,os
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();base=pathlib.Path('.codex-checks/theme-overhaul');results=[]
batches=[('closed-b','closed','ArcticDawn,SolarPop,ContourAtlas,WaterLilies',False),('closed-lily-extra','closed','WaterLilies',True),('open-a','open','DesertWarm,OceanCool,ForestGreen,SakuraCalm',False),('open-b','open','ArcticDawn,SolarPop,ContourAtlas,WaterLilies',False),('open-lily-extra','open','WaterLilies',True)]
for label,pose,themes,extra in batches:
 if subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()!=source or subprocess.check_output(['git','status','--porcelain'],text=True).strip():raise SystemExit('Source changed; stop before next native batch')
 cmd=['python3','scripts/codex-pipeline.py','run','theme-duo-'+label,'--context','xcode27B52-ios27.2-'+source[:9]+'-D1E42917-'+label,'--scope','all','--content-only','--timeout','1500','--','python3','scripts/lib/simulator-test-lock.py','.','--','python3',str(base/'run-duo-theme-batch.py'),pose,'--themes',themes]
 if extra:cmd+=['--include-lily-extras']
 print('Starting Duo '+label+' exact bounded batch',flush=True);start=time.time();code=subprocess.call(cmd,env=dict(os.environ,DAILVE_UI_TEST_DERIVED_DATA_DIR='.deriveddata/unit-tests'))
 results.append({'label':label,'pose':pose,'themes':themes,'lily_extras':extra,'source_revision':source,'exit_code':code,'started':start,'ended':time.time()});(base/'duo-remaining-batches.json').write_text(json.dumps(results,indent=2)+'\n')
 if code:sys.exit(code)
print('Completed remaining native Duo batches',flush=True)
