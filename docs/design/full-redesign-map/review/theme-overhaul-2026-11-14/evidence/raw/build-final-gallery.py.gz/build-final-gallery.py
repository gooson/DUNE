from pathlib import Path
import html,json

root=Path(__file__).resolve().parents[2]
review=root/'docs/design/full-redesign-map/review/theme-overhaul-2026-11-14'
cards=[]
for kind,label in [('regular','iPhone'),('ipad','iPad'),('duo','Duo 접힘')]:
    data=json.loads((root/f'docs/design/full-redesign-map/actual/{kind}/capture-index.json').read_text())
    for key,record in sorted(data['captures'].items()):
        theme,appearance,screen=key.split('/')
        prefix=f'../../actual/{kind}/'
        image=prefix+record['file'];ax=prefix+record['ax_file']
        title=f'{label} · {theme} · {appearance} · {screen}'
        cards.append(f'<article data-device="{kind}" data-theme="{theme}" data-appearance="{appearance}"><a href="{image}"><img loading="lazy" src="{image}" alt="{html.escape(title)} 실제 앱 캡처"></a><h2>{html.escape(title)}</h2><p>{html.escape(record["viewport_pixels"])} · <a href="{ax}">AX 원본</a></p><p>촬영 소스 <code>{record["source_revision"][:9]}</code> · <a href="{prefix}capture-index.json">시각·기기·SHA-256</a></p></article>')
assert len(cards)==192
page='''<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>8개 테마 실제 화면 · 2026-11-14</title><style>body{font:16px/1.6 system-ui,sans-serif;background:#151817;color:#eee;margin:0}main{max-width:1440px;margin:auto;padding:24px}a{color:#e9c28e}h1{font-size:28px}h2{font-size:16px;margin:8px 0}p{margin:6px 0}nav{display:flex;gap:12px;flex-wrap:wrap;margin:20px 0}select{font:inherit;padding:8px;background:#262c29;color:#eee;border:1px solid #69736c;border-radius:8px}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:20px}article{padding:12px;background:#222825;border-radius:12px}article img{width:100%;max-height:560px;object-fit:contain}article p{font-size:13px}code{overflow-wrap:anywhere}[hidden]{display:none!important}</style><main><h1>8개 테마 실제 화면</h1><p>2026-11-14 · iPhone·iPad·Duo 접힘의 4탭 밝음·어두움 실제 PNG와 AX 192쌍입니다. 시안과 구분하며 촬영 당시 소스를 유지합니다.</p><p><a href="README.md">실행 결과·실패·미검증 범위</a> · <a href="../../index.html">전체 구현 맵</a> · <a href="../../../phone-design-map/actual/index.html">통합 실제 화면맵</a> · <a href="evidence/evidence-files.json">원본 실행 증거 목록</a></p><p>Duo 펼침 T03·A01·H01·L01 × 8테마 × 밝음·어두움은 이번 소스에서 미캡처입니다. 전용 기기에서 내부 패널이 활성화되지 않았습니다. 위젯 렌더링·Vision 실행·Watch 실전파도 통과로 표시하지 않습니다.</p><nav><label>기기 <select id="device"><option value="">모두</option><option value="regular">iPhone</option><option value="ipad">iPad</option><option value="duo">Duo 접힘</option></select></label><label>테마 <select id="theme"><option value="">모두</option>'''
page+=''.join(f'<option>{x}</option>' for x in ['dune','ocean','forest','sakura','arctic','solar','contour','water-lilies'])
page+='''</select></label><label>표현 <select id="appearance"><option value="">모두</option><option value="light">light</option><option value="dark">dark</option></select></label></nav><p id="count" aria-live="polite">192장</p><div class="grid">'''+''.join(cards)+'''</div></main><script>const fields=['device','theme','appearance'];function filter(){let count=0;document.querySelectorAll('article').forEach(a=>{const visible=fields.every(k=>!document.getElementById(k).value||a.dataset[k]===document.getElementById(k).value);a.hidden=!visible;if(visible)count++});document.getElementById('count').textContent=count+'장'}fields.forEach(k=>document.getElementById(k).addEventListener('change',filter));</script></html>'''
review.joinpath('index.html').write_text(page)
print('Built native review gallery: 192 PNG+AX pairs')
