import argparse,json,os,pathlib,re,subprocess,sys,time
p=argparse.ArgumentParser();p.add_argument('name');p.add_argument('udid');p.add_argument('--setting',choices=['voiceover','contrast']);p.add_argument('selectors',nargs='+');a=p.parse_args()
root=pathlib.Path.cwd();base=root/'.codex-checks/theme-overhaul';log=base/(a.name+'.log');output=base/'exports'/a.name
fds=tuple(int(os.environ[k]) for k in ['DUNE_SIM_TEST_LOCK_FD','DUNE_SIM_TEST_WORKTREE_LOCK_FD'] if k in os.environ)
def call(args,**kwargs):return subprocess.run(args,timeout=kwargs.pop('timeout',None),pass_fds=fds,**kwargs)
def voice(stage,change=None):
 path=base/(a.name+'-'+stage+'.json')
 cmd=['xcrun','devicectl','device',('settings' if change is not None else 'info'),'voiceover','--device',a.udid,'--timeout','15','--quiet','--json-output',str(path)]
 if change is not None:cmd += ['--enable' if change else '--disable']
 call(cmd,check=True,timeout=25)
 return json.loads(path.read_text())['result']['enabled']
def contrast(stage,change=None):
 cmd=['xcrun','simctl','ui',a.udid,'increase_contrast']
 if change is not None:cmd += ['enabled' if change else 'disabled']
 r=call(cmd,check=True,capture_output=True,text=True,timeout=20)
 if change is not None:return contrast(stage)
 value=r.stdout.strip();(base/(a.name+'-'+stage+'.json')).write_text(json.dumps({'udid':a.udid,'increase_contrast':value,'time':time.time()})+'\n')
 if value not in ['enabled','disabled']:raise RuntimeError('Unknown contrast readback '+value)
 return value=='enabled'
setter=voice if a.setting=='voiceover' else contrast if a.setting else None
before=setter('before') if setter else None
record={'source_revision':call(['git','rev-parse','HEAD'],check=True,capture_output=True,text=True).stdout.strip(),'source_worktree_dirty':bool(call(['git','status','--porcelain'],check=True,capture_output=True,text=True).stdout.strip()),'udid':a.udid,'selectors':a.selectors,'started':time.time(),'setting':a.setting,'original_setting':before}
code=1
try:
 if setter:
  setter('set-enabled',True)
  if not setter('enabled'):raise RuntimeError('System setting did not enable')
 command=['scripts/test-ui.sh','--no-regen','--simulator-udid',a.udid,'--test-plan','DUNEUITests-DesignCapture','--log-file',str(log)]
 for s in a.selectors:command += ['--only-testing',s]
 env=dict(os.environ,DUNE_UI_TEST_WALL_TIMEOUT='1200',DAILVE_UI_TEST_DERIVED_DATA_DIR='.deriveddata/unit-tests')
 code=call(command,env=env).returncode;record['exit_code']=code
 matches=re.findall(r'^\s*(/.*\.xcresult)\s*$',log.read_text(),re.M) if log.exists() else []
 if matches and pathlib.Path(matches[-1]).exists():
  record['result_bundle']=matches[-1]
  with (base/(a.name+'-export.log')).open('w') as stream:
   call(['xcrun','xcresulttool','export','attachments','--path',matches[-1],'--output-path',str(output)],stdout=stream,stderr=subprocess.STDOUT,check=True,timeout=180)
  if not (output/'manifest.json').is_file():raise RuntimeError('No export manifest')
  for kind in ['summary','tests']:
   r=call(['xcrun','xcresulttool','get','test-results',kind,'--path',matches[-1],'--format','json'],capture_output=True,text=True,timeout=30)
   if r.returncode==0:(output/(kind+'.json')).write_text(r.stdout)
  print('Preserved '+str(output),flush=True)
 else:record['artifact_error']='No result bundle'
finally:
 if setter:
  try:
   setter('restore',before);record['restored_setting']=setter('restored')
   if record['restored_setting']!=before:record['restore_error']='System setting mismatch';code=1
  except Exception as e:record['restore_error']=str(e);code=1
 record['ended']=time.time();(base/(a.name+'-provenance.json')).write_text(json.dumps(record,indent=2)+'\n')
sys.exit(code)
