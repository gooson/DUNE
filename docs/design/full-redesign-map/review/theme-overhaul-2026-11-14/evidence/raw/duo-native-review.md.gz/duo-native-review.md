# Duo closed native visual preview — first four themes

**Preview only; batch completion not claimed.** Source is the raw directory `duo-theme-closed-DesertWarm-OceanCool-ForestGreen-SakuraCalm-20261114T120247Z`. Official preflight reports active LCD 1398 × 2034 px portrait, AX viewport 466 × 678 pt, and hinge angle `null`. I selected only `checkpoints.jsonl` rows with `acknowledged: true` and `valid_evidence: true`, canonical theme/screen actions, and the same-sequence `-1398x2034.png` plus `-hierarchy.txt`. Inactive 2007 × 2853 captures were excluded. Parent will validate the collected batch with the corrected postflight parser and receipt; the old `Window,` parser did not match the current `Window(Main)` AX text.

## Sampled images and AX

- Desert Light Today/Wellness/Life: `002`, `006`, `008`; Dark Today: `009`.
- Forest Light Today/Wellness/Life: `019`, `023`, `025`; Dark Today/Wellness/Life: `026`, `030`, `032`.
- All sequence numbers refer to matching files in the raw directory. The paired AX has `dashboard-hero-condition` and `dashboard-hourly-condition-chart` within the 318 pt content width for Today; Life `life-past-record-button` is `{298.3, 289.7, 67.7, 44.0}` (right edge 366 pt, within the 466 pt active viewport).

## Observations

- No concrete P1/P2/P3 defect in these sampled first viewports. The narrower active LCD uses a vertical four-tab rail at the right and a 318 pt Today hero at the left. The hero message wraps within its card; score, trend line, time range, and delta chips remain readable. Forest ridges and Desert dunes sit behind the header/rail without obscuring their controls.
- Wellness score, evidence bars, labels, and expand action fit the card in both sampled light appearances and Forest Dark. Life history action, filters, and first habit controls remain visible; lower cards continue beneath the viewport for scrolling. No cropped glyph or horizontal overflow is apparent in the sampled PNGs.

This preview does not establish completion of the running UI batch, all 32 canonical first-four-theme screens, hinge-angle measurement, full scrolling, Duo open posture, MAX text size, motion, or spoken VoiceOver output.
