#!/usr/bin/env python3
"""Validate and optionally promote a complete native Watch theme capture batch.

Default is a read-only dry run. Inputs are an already-exported XCResult
manifest, its exported attachment directory, and authoritative run receipts.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import struct
import tempfile
import time


ROOT = Path(__file__).resolve().parents[2]
DEST = ROOT / "docs/design/full-redesign-map/actual/watch"
BASE_REV = "96d1a60e5"
THEMES = {
    "Desert": "dune", "Ocean": "ocean", "Forest": "forest", "Sakura": "sakura",
    "Arctic": "arctic", "Solar": "solar", "Contour": "contour", "Water Lilies": "water-lilies",
}
SCENES = {"Home": "home", "All Exercises": "all-exercises", "Workout": "workout"}
PNG = re.compile(r"^(Desert|Ocean|Forest|Sakura|Arctic|Solar|Contour|Water Lilies) Watch (Home|All Exercises|Workout)_\d+_([0-9a-fA-F-]{36})\.png$")
AX = re.compile(r"^hierarchy-(Desert|Ocean|Forest|Sakura|Arctic|Solar|Contour|Water Lilies) Watch (Home|All Exercises|Workout)(?:[-_].*)?$")
WINDOW = re.compile(r"^\s*Window(?: \(Main\))?,[^\n]*?\{\{\s*[-\d.]+\s*,\s*[-\d.]+\s*\},\s*\{\s*([\d.]+)\s*,\s*([\d.]+)\s*\}\}")


def read(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as f:
        header = f.read(24)
    if len(header) != 24 or header[:8] != b"\x89PNG\r\n\x1a\n" or header[12:16] != b"IHDR":
        raise ValueError(f"invalid PNG: {path}")
    return struct.unpack(">II", header[16:24])


def ax_dimensions(path: Path) -> tuple[float, float]:
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        match = WINDOW.search(line)
        if match:
            return float(match.group(1)), float(match.group(2))
    raise ValueError(f"AX hierarchy has no Window (Main): {path}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True, help="Pre-exported xcresult manifest.json")
    parser.add_argument("--export-dir", type=Path, required=True, help="Directory containing manifest exportedFileName files")
    parser.add_argument("--provenance", type=Path, required=True, help="Authoritative watch-native-provenance.json")
    parser.add_argument("--receipt", type=Path, required=True, help="Positive watch-native.log.result.json")
    parser.add_argument("--device-registry", type=Path, default=ROOT / ".codex-checks/worktree-simulators.json", help="Read-only owned simulator registry")
    parser.add_argument("--apply", action="store_true", help="Atomically replace the Watch theme map after validation")
    parser.add_argument("--allow-device-replacement", action="store_true", help="Permit replacing the old Watch UID only for a complete newer 24-screen set")
    args = parser.parse_args()

    proof, receipt, manifest = read(args.provenance), read(args.receipt), read(args.manifest)
    revision = proof.get("source_revision")
    if not revision or proof.get("source_worktree_dirty") is not False:
        raise ValueError("source must have an explicit revision and source_worktree_dirty=false")
    udid = proof.get("udid") or proof.get("device", {}).get("identifier")
    if not udid:
        raise ValueError("provenance must identify the Watch simulator")
    registry = read(args.device_registry)
    owner = [item for item in registry if item.get("udid") == udid and item.get("worktree") == str(ROOT)]
    if len(owner) != 1:
        raise ValueError("device registry does not prove exactly one Watch simulator owned by this worktree")
    model_name = owner[0].get("name", "Apple Watch").split("-wt-", 1)[0]
    device = {"kind": "watch", "platform": "watchOS Simulator", "model_name": model_name, "identifier": udid}
    if receipt.get("status") != "passed" or receipt.get("run_exit_status") != 0:
        raise ValueError("Watch UI receipt is not passed")
    counts = receipt.get("counts", {})
    if counts.get("executed") != 16 or counts.get("passed") != 16 or counts.get("failed") != 0:
        raise ValueError(f"expected all 16 Watch theme selectors passed, got {counts}")

    requested = set(receipt.get("requested_selectors", []))
    expected_selectors = {
        f"DUNEWatchUITests/WatchThemeMatrixUITests/test{theme.replace(' ', '')}{suffix}"
        for theme in THEMES for suffix in ("HomeAndExerciseList", "WorkoutTheme")
    }
    if requested != expected_selectors or set(proof.get("selectors", [])) != expected_selectors:
        raise ValueError("provenance and receipt must cover exactly all 16 theme selectors")

    selected: dict[str, dict] = {}
    for test in manifest:
        test_id = test.get("testIdentifier", "")
        test_short = test_id.removesuffix("()")
        for att in test.get("attachments", []):
            if att.get("isAssociatedWithFailure", False) or att.get("deviceId") != udid:
                continue
            name = att.get("suggestedHumanReadableName", "")
            pm = PNG.fullmatch(Path(name).name)
            am = AX.fullmatch(Path(name).name)
            if not pm and not am:
                continue
            theme_name, scene_name = (pm or am).group(1), (pm or am).group(2)
            theme, scene = THEMES[theme_name], SCENES[scene_name]
            expected_tail = "WorkoutTheme" if scene == "workout" else "HomeAndExerciseList"
            if not test_short.endswith(f"test{theme_name.replace(' ', '')}{expected_tail}"):
                raise ValueError(f"scene attachment associated with wrong test: {name} / {test_id}")
            file_name = att.get("exportedFileName")
            file_path = (args.export_dir / str(file_name or "")).resolve()
            if not file_name or not file_path.is_relative_to(args.export_dir.resolve()) or not file_path.is_file():
                raise ValueError(f"missing exported attachment bytes for {name}")
            key = f"{theme}/{scene}"
            slot = selected.setdefault(key, {"test_identifier": test_short})
            if slot["test_identifier"] != test_short:
                raise ValueError(f"PNG and AX came from different test methods: {key}")
            kind = "png" if pm else "ax"
            if kind in slot:
                raise ValueError(f"duplicate {kind} attachment for {key}")
            slot[kind] = {"name": name, "path": file_path, "timestamp": float(att.get("timestamp") or 0), "uuid": pm.group(3) if pm else None}

    expected_keys = {f"{theme}/{scene}" for theme in THEMES.values() for scene in SCENES.values()}
    if set(selected) != expected_keys:
        raise ValueError(f"expected 24 unique screen keys; got {len(selected)} missing={sorted(expected_keys-set(selected))}")
    captures = {}
    for key, pair in selected.items():
        if set(pair) != {"test_identifier", "png", "ax"}:
            raise ValueError(f"unpaired PNG/AX for {key}")
        png, ax = pair["png"], pair["ax"]
        if abs(png["timestamp"] - ax["timestamp"]) > 5:
            raise ValueError(f"PNG/AX timestamp gap exceeds 5s for {key}")
        ax_uuid_match = re.search(r"_\d+_([0-9a-fA-F-]{36})(?:\.swift-\d+)?$", Path(ax["name"]).name)
        ax_uuid = ax_uuid_match.group(1) if ax_uuid_match else None
        dimensions = png_dimensions(png["path"])
        points = ax_dimensions(ax["path"])
        if any(abs(px / pt - 2.0) > 0.12 for px, pt in zip(dimensions, points)):
            raise ValueError(f"PNG/AX viewport mismatch for {key}: {dimensions} vs {points}")
        if png["timestamp"] <= 0:
            raise ValueError(f"missing source timestamp for {key}")
        captures[key] = {
            "theme": key.split("/")[0], "scene": key.split("/")[1],
            "file": f"{key}.png", "ax_file": f"ax/{key}.txt",
            "attachment_name": png["name"], "ax_attachment_name": ax["name"],
            "test_identifier": pair["test_identifier"], "timestamp": png["timestamp"],
            "ax_timestamp": ax["timestamp"], "timestamp_source": "xcresult-attachment-timestamp",
            "pairing_method": "same-test-scene-within-5s; XCTest attachments are sequential, UUIDs need not match",
            "png_activity_uuid": png["uuid"], "ax_activity_uuid": ax_uuid,
            "viewport_pixels": f"{dimensions[0]}x{dimensions[1]} px",
            "logical_viewport_points": f"{points[0]}x{points[1]} pt",
            "device": device,
            "source_revision": revision, "source_worktree_dirty": False,
            "source_worktree": proof.get("worktree"),
            "source_manifest": str(args.manifest.resolve()), "source_proof": str(args.provenance.resolve()),
            "source_receipt": str(args.receipt.resolve()),
            "source_png": str(png["path"].resolve()), "source_ax": str(ax["path"].resolve()),
            "sha256": sha(png["path"]), "sha256_ax": sha(ax["path"]),
            "native_size": list(dimensions), "window_size_pt": list(points),
        }

    previous = read(DEST / "capture-index.json")
    old = previous.get("captures", {})
    if set(old) != expected_keys:
        raise ValueError("existing destination does not have the expected same 24 keys")
    old_device = previous.get("device", {}).get("identifier")
    if old_device != udid and not args.allow_device_replacement:
        raise ValueError(f"device replacement {old_device} -> {udid} requires --allow-device-replacement")
    for key, record in captures.items():
        if captures[key]["timestamp"] <= float(old[key].get("timestamp") or 0):
            raise ValueError(f"new Watch capture is not newer: {key}")
    previous_index_sha = sha(DEST / "capture-index.json")
    print(f"Validated {len(captures)} Watch PNG+AX pairs; device {old_device} -> {udid}; revision {revision}; previous index sha256 {previous_index_sha}")
    if not args.apply:
        print("Dry run only. No tracked files changed.")
        return 0

    ready = Path(tempfile.mkdtemp(prefix=".watch-theme-ready-", dir=DEST.parent))
    backup = None
    try:
        # Preserve directory shape and any adjacent Watch assets, then replace only 24 PNGs/index and add AX.
        shutil.copytree(DEST, ready, dirs_exist_ok=True)
        for key, record in captures.items():
            src_png, src_ax = selected[key]["png"]["path"], selected[key]["ax"]["path"]
            for src, rel, hash_key in ((src_png, record["file"], "sha256"), (src_ax, record["ax_file"], "sha256_ax")):
                target = ready / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(src, target)
                if sha(target) != record[hash_key]:
                    raise ValueError(f"copy hash mismatch for {key} {rel}")
        payload = {
            "schema_version": 1,
            "device": device,
            "source_revision": revision, "source_worktree_dirty": False,
            "replacement": {"previous_index_sha256": previous_index_sha, "previous_device_identifier": old_device, "base_revision": BASE_REV},
            "captures": captures,
        }
        (ready / "capture-index.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        backup = Path(tempfile.mkdtemp(prefix=".watch-theme-backup-", dir=DEST.parent))
        backup.rmdir()
        os.replace(DEST, backup)
        try:
            os.replace(ready, DEST)
        except Exception:
            os.replace(backup, DEST)
            raise
        shutil.rmtree(backup)
        print(f"Promoted 24 Watch PNG+AX pairs to {DEST}")
    finally:
        if ready.exists():
            shutil.rmtree(ready, ignore_errors=True)
        if backup is not None and backup.exists():
            shutil.rmtree(backup, ignore_errors=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as exc:
        raise SystemExit(f"error: {exc}")
