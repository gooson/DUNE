#!/usr/bin/env python3
"""Validate and optionally promote a complete 64-screen theme stage.

Default mode is read-only. --apply is the only mode that writes the tracked
full-redesign-map actual captures.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import tempfile
import sys


ROOT = Path(__file__).resolve().parents[2]
ACTUAL_ROOT = ROOT / "docs/design/full-redesign-map/actual"
BASE_GIT_REVISION = "96d1a60e5"
THEMES = ("dune", "ocean", "forest", "sakura", "arctic", "solar", "contour", "water-lilies")
APPEARANCES = ("light", "dark")
SCREENS = ("T03", "A01", "H01", "L01")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def expected_keys() -> set[str]:
    return {f"{theme}/{appearance}/{screen}" for theme in THEMES
            for appearance in APPEARANCES for screen in SCREENS}


def load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def inspect_stage(stage: Path, kind: str, target: Path, allow_device_replacement: bool) -> dict:
    provenance_path = stage / "provenance.json"
    provenance = load_json(provenance_path)
    device = provenance.get("device")
    if not isinstance(device, dict):
        raise ValueError("stage has no device metadata")
    device_id = device.get("identifier")
    if not isinstance(device_id, str) or not device_id:
        raise ValueError("stage device has no identifier")
    if device.get("kind") != kind:
        raise ValueError(f"stage kind {device.get('kind')!r} does not match target {kind!r}")
    source_revision = provenance.get("source_revision")
    source_worktree = provenance.get("source_worktree")
    captures = provenance.get("captures")
    if not isinstance(source_revision, str) or not source_revision or not isinstance(source_worktree, str) or not source_worktree:
        raise ValueError("stage source revision/worktree provenance is missing")
    if not isinstance(captures, dict):
        raise ValueError("stage captures must be an object")
    expected = expected_keys()
    keys = set(captures)
    if keys != expected:
        raise ValueError(f"stage must contain exactly 64 expected keys (missing={len(expected-keys)}, unknown={len(keys-expected)})")

    index_path = target / "capture-index.json"
    old_index = load_json(index_path) if index_path.is_file() else {"schema_version": 1, "captures": {}}
    old_captures = old_index.get("captures")
    if not isinstance(old_captures, dict):
        raise ValueError(f"existing index has no captures object: {index_path}")
    old_keys = set(old_captures)
    if not old_keys <= expected:
        raise ValueError(f"existing index contains unexpected keys: {sorted(old_keys - expected)}")
    previous_device = old_index.get("device", {})
    old_device_id = previous_device.get("identifier") if isinstance(previous_device, dict) else None
    device_replaced = bool(old_device_id and old_device_id != device_id)
    if device_replaced and not allow_device_replacement:
        raise ValueError(f"device replacement requires --allow-device-replacement ({old_device_id} -> {device_id})")

    entries = {}
    older_count = 0
    pixel_viewports = set()
    logical_viewports = set()
    for key in sorted(expected):
        incoming = captures[key]
        if not isinstance(incoming, dict):
            raise ValueError(f"capture record is not an object: {key}")
        record_device = incoming.get("device")
        if not isinstance(record_device, dict) or record_device.get("identifier") != device_id:
            raise ValueError(f"capture device does not match stage device: {key}")
        if incoming.get("source_revision") != source_revision or incoming.get("source_worktree") != source_worktree:
            raise ValueError(f"capture source metadata does not match stage: {key}")
        if incoming.get("source_worktree_dirty") is not False:
            raise ValueError(f"capture must have authoritative source_worktree_dirty=false: {key}")
        timestamp = incoming.get("timestamp")
        if not isinstance(timestamp, (int, float)) or not math.isfinite(float(timestamp)):
            raise ValueError(f"capture timestamp is missing or invalid: {key}")
        if incoming.get("file") != f"images/{key}.png" or incoming.get("ax_file") != f"ax/{key}.txt":
            raise ValueError(f"stage source paths are not canonical for {key}")
        source_png = stage / incoming["file"]
        source_ax = stage / incoming["ax_file"]
        if not source_png.is_file() or not source_ax.is_file():
            raise ValueError(f"staged PNG or AX file is missing: {key}")
        png_hash, ax_hash = sha256(source_png), sha256(source_ax)
        if incoming.get("sha256_png") != png_hash or incoming.get("sha256_ax") != ax_hash:
            raise ValueError(f"staged PNG/AX SHA-256 mismatch: {key}")
        if key in old_captures:
            old_record = old_captures[key]
            if not isinstance(old_record, dict):
                raise ValueError(f"existing capture record is invalid: {key}")
            try:
                old_timestamp = float(old_record.get("timestamp"))
            except (TypeError, ValueError):
                raise ValueError(f"existing timestamp is invalid: {key}")
            if not math.isfinite(old_timestamp) or float(timestamp) <= old_timestamp:
                raise ValueError(f"incoming capture is not newer than existing entry: {key}")
            old_file = target / str(old_record.get("file", ""))
            if not old_record.get("file") or not old_file.resolve().is_relative_to(target.resolve()):
                raise ValueError(f"existing indexed path escapes the target: {key}")
            if not old_file.is_file():
                raise ValueError(f"existing indexed PNG is missing: {old_file}")
            older_count += 1

        clean = {name: value for name, value in incoming.items() if not name.startswith("_")}
        clean["theme_id"] = clean["theme"]
        clean["state"] = clean["appearance"]
        clean["file"] = f"{key}.png"
        clean["ax_file"] = f"ax/{key}.txt"
        clean["device"] = device
        clean["device_id"] = device_id
        entries[key] = clean
        pixel_viewports.add(clean.get("viewport_pixels"))
        logical_viewports.add(clean.get("logical_viewport_points"))

    if len(pixel_viewports) != 1 or None in pixel_viewports or len(logical_viewports) != 1 or None in logical_viewports:
        raise ValueError(f"stage mixes or omits viewport metadata: pixels={pixel_viewports}, points={logical_viewports}")
    index_payload = {
        "schema_version": 1,
        "device": device,
        "source_revision": source_revision,
        "source_worktree": source_worktree,
        "source_worktree_dirty": False,
        "viewport_pixels": next(iter(pixel_viewports)),
        "logical_viewport_points": next(iter(logical_viewports)),
        "promotion": {
            "prior_index_path": str(index_path.relative_to(ROOT)),
            "prior_index_sha256": sha256(index_path) if index_path.is_file() else None,
            "base_git_revision": BASE_GIT_REVISION,
            "prior_device": previous_device,
            "device_replacement_allowed": allow_device_replacement,
        },
        "captures": entries,
    }
    return {
        "kind": kind,
        "stage": stage,
        "target": target,
        "index_path": index_path,
        "index_sha256": sha256(index_path) if index_path.is_file() else None,
        "device": device,
        "device_replaced": device_replaced,
        "old_count": len(old_keys),
        "new_count": len(entries),
        "newer_count": older_count,
        "viewport_pixels": next(iter(pixel_viewports)),
        "logical_viewport_points": next(iter(logical_viewports)),
        "captures": entries,
        "index_payload": index_payload,
    }


def apply(plan: dict) -> None:
    index_path = plan["index_path"]
    current_hash = sha256(index_path) if index_path.is_file() else None
    if current_hash != plan["index_sha256"]:
        raise ValueError(f"target index changed after planning: {index_path}")
    target = plan["target"]
    target.mkdir(parents=True, exist_ok=True)
    for key, record in sorted(plan["captures"].items()):
        theme, appearance, screen = key.split("/")
        png_source = plan["stage"] / record["file"].replace(f"{key}.png", f"images/{key}.png")
        ax_source = plan["stage"] / f"ax/{key}.txt"
        png_target = target / f"{key}.png"
        ax_target = target / f"ax/{key}.txt"
        for source, destination, expected_hash in (
            (png_source, png_target, record["sha256_png"]),
            (ax_source, ax_target, record["sha256_ax"]),
        ):
            if sha256(source) != expected_hash:
                raise ValueError(f"source changed after planning: {source}")
            destination.parent.mkdir(parents=True, exist_ok=True)
            descriptor, temporary_name = tempfile.mkstemp(prefix=f".{destination.name}.", dir=destination.parent)
            os.close(descriptor)
            temporary = Path(temporary_name)
            try:
                shutil.copyfile(source, temporary)
                if sha256(temporary) != expected_hash:
                    raise ValueError(f"copy hash mismatch: {destination}")
                os.replace(temporary, destination)
            finally:
                temporary.unlink(missing_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=".capture-index.", suffix=".json", dir=target)
    os.close(descriptor)
    temporary_index = Path(temporary_name)
    try:
        temporary_index.write_text(json.dumps(plan["index_payload"], ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(temporary_index, index_path)
    finally:
        temporary_index.unlink(missing_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("kind", choices=("regular", "ipad", "duo", "duo-open"))
    parser.add_argument("--stage", type=Path, help="validated staging directory (defaults to stage-<kind>)")
    parser.add_argument("--allow-device-replacement", action="store_true",
                        help="allow a complete 64-capture refresh from a different simulator UDID")
    parser.add_argument("--apply", action="store_true", help="write PNG, AX, and capture-index files; default is dry-run")
    args = parser.parse_args()
    stage = args.stage or ROOT / f".codex-checks/theme-overhaul/stage-{args.kind}"
    target = ACTUAL_ROOT / args.kind
    plan = inspect_stage(stage, args.kind, target, args.allow_device_replacement)
    action = "APPLY" if args.apply else "DRY-RUN"
    print(f"{action} {args.kind}: {plan['new_count']} PNG+AX pairs; replacing {plan['old_count']} indexed screens")
    print(f"Device: {plan['device'].get('model_name')} [{plan['device'].get('identifier')}]" +
          (" (device replacement authorized)" if plan["device_replaced"] else ""))
    print(f"Source: {plan['index_payload']['source_revision']} dirty=false; viewport {plan['viewport_pixels']} / {plan['logical_viewport_points']}")
    print(f"Newer than existing: {plan['newer_count']}/{plan['old_count']} indexed keys")
    print(f"Target: {target}/<theme>/<appearance>/<screen>.png + ax/<key>.txt")
    print(f"Index: {plan['index_path']} (prior SHA-256 {plan['index_sha256'] or 'absent'}; base {BASE_GIT_REVISION})")
    if args.apply:
        apply(plan)
        print("Promotion complete.")
    else:
        print("Dry-run only: no files written. Add --apply to promote after review.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, json.JSONDecodeError) as error:
        print(f"error: {error}", file=sys.stderr)
        raise SystemExit(2)
