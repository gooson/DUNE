#!/usr/bin/env python3
"""Keep pinned SimDuoHID alive through its async dispatch and official readback."""
import json,os,select,subprocess,sys,time
from pathlib import Path
DEVICE='5B59EC29-360D-4AA9-B01F-31A8C9814FAB'
TOKENS={'portrait':'1','landscapeLeft':'3','landscapeRight':'4'}
def main():
    if len(sys.argv)!=4 or sys.argv[1:3]!=['-d',DEVICE] or sys.argv[3] not in TOKENS:
        raise SystemExit('Expected -d <owned Duo UDID> portrait|landscapeLeft|landscapeRight')
    direction=sys.argv[3];binary=Path(os.environ['DUNE_THEME_DUO_HID_BIN']).resolve(strict=True)
    if not binary.is_file() or not os.access(binary,os.X_OK):raise SystemExit('Pinned orientation binary unavailable')
    record={'device':DEVICE,'target':direction,'commands_sent':0,'retained_stdin':True,'settle_seconds':1.2,'started':time.time()}
    child=None;success=False
    try:
        child=subprocess.Popen(['xcrun','simctl','spawn',DEVICE,str(binary)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        record['owned_simctl_pid']=child.pid
        child.stdin.write('orientation '+TOKENS[direction]+'\n');child.stdin.flush();record['commands_sent']=1
        if not select.select([child.stdout],[],[],3)[0]:raise RuntimeError('No helper ACK within 3 seconds')
        ack=child.stdout.readline().strip();record['ack']=ack
        if ack!='OK':raise RuntimeError('Unexpected helper ACK: '+ack)
        time.sleep(1.2)
        readback=subprocess.run(['xcrun','devicectl','device','orientation','get','--device',DEVICE,'--timeout','10','--quiet','--json-output','-'],capture_output=True,text=True,timeout=12,check=True)
        record['official_readback_while_alive']=json.loads(readback.stdout)
        actual=record['official_readback_while_alive']['result']['deviceOrientation']
        if actual!=direction:raise RuntimeError('Retained helper readback mismatch: '+actual)
        success=True
    except Exception as error:
        record['error']=str(error)
    finally:
        if child:
            if child.stdin:child.stdin.close()
            try:child.wait(timeout=3)
            except subprocess.TimeoutExpired:
                record['forced_cleanup']=True;child.terminate()
                try:child.wait(timeout=2)
                except subprocess.TimeoutExpired:child.kill();child.wait(timeout=2)
                success=False
            record['helper_exit_code']=child.returncode
            if child.returncode:success=False
            record['stderr']=child.stderr.read()[-800:]
        record['ended']=time.time();record['status']='passed' if success else 'failed'
        path=binary.parent.parent/('orientation-driver-'+str(time.time_ns())+'.json')
        path.write_text(json.dumps(record,indent=2)+'\n')
    if not success:
        print('Duo orientation not verified: '+json.dumps(record),file=sys.stderr);return 1
    print('OK');return 0
if __name__=='__main__':raise SystemExit(main())
