import json,os,pathlib,re,subprocess,sys,time
root=pathlib.Path.cwd();base=root/'.codex-checks/theme-overhaul';log=base/'watch-native.log';out=base/'exports/watch-native'
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
if subprocess.check_output(['git','status','--porcelain'],text=True).strip():raise SystemExit('Freeze tracked source before Watch validation')
selectors=['DUNEWatchUITests/WatchThemeMatrixUITests/test'+theme+scene for theme in ['Desert','Ocean','Forest','Sakura','Arctic','Solar','Contour','WaterLilies'] for scene in ['HomeAndExerciseList','WorkoutTheme']]
record={'source_revision':source,'source_worktree_dirty':False,'worktree':str(root),'selectors':selectors,'started':time.time(),'scope':'16 exact Watch theme methods; native3scenes pertheme, fixture override, not transport proof'}
cmd=['scripts/test-watch-ui.sh','--no-regen','--test-plan','DUNEWatchUITests-Full','--log-file',str(log)]
for selector in selectors:cmd+=['--only-testing',selector]
env=dict(os.environ,DUNE_WATCH_SIM_NAME='Apple Watch Series 12 (46mm)',DUNE_WATCH_SIM_OS='27.2',DUNE_UI_TEST_WALL_TIMEOUT='1200',DAILVE_WATCH_UI_TEST_DERIVED_DATA_DIR='.deriveddata/unit-tests')
code=subprocess.call(cmd,env=env);record['exit_code']=code
matches=re.findall(r'^\s*(/.*\.xcresult)\s*$',log.read_text(),re.M) if log.exists() else []
if matches and pathlib.Path(matches[-1]).exists():
 record['result_bundle']=matches[-1]
 with (base/'watch-native-export.log').open('w') as stream:subprocess.run(['xcrun','xcresulttool','export','attachments','--path',matches[-1],'--output-path',str(out)],stdout=stream,stderr=subprocess.STDOUT,check=True,timeout=180)
 for kind in ['summary','tests']:
  r=subprocess.run(['xcrun','xcresulttool','get','test-results',kind,'--path',matches[-1],'--format','json'],capture_output=True,text=True,timeout=30)
  if r.returncode==0:(out/(kind+'.json')).write_text(r.stdout)
else:record['artifact_error']='Result bundle missing';code=1
record['ended']=time.time();(base/'watch-native-provenance.json').write_text(json.dumps(record,indent=2)+'\n');sys.exit(code)
