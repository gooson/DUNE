# Platform verification handoff

Read-only prep only; no build or simulator action was run. Source guidance: `.codex/skill-compat.md`, `.codex/ui-execution.md`, `scripts/test-watch-ui.sh`, `scripts/test-ui.sh`, and the collectors.

## iPad mini (A20 Pro)

Selector: `DUNEUITests/ThemeMatrixUITests/testWaterLiliesMatrix` (captures Water Lilies Light/Dark for Today, Activity, Wellness, Life). Run on a **registered worktree-owned clone** of template `5580B916-E60A-4E0D-BD31-D6528FA4B370`, with its clone UDID substituted below:

```sh
IPAD_CLONE_UDID='<registered worktree clone UDID>'
DUNE_UI_TEST_WALL_TIMEOUT=1200 scripts/test-ui.sh --no-regen --test-plan DUNEUITests-DesignCapture --simulator-udid "$IPAD_CLONE_UDID" --log-file .codex-checks/theme-overhaul/ipad-water-lilies.log --only-testing DUNEUITests/ThemeMatrixUITests/testWaterLiliesMatrix
```

The current registry has no iPad clone, only phone clones. `--simulator-udid` is strict and will not clone an explicit target; do not pass the template UDID. Provision/register an owned clone first. `scripts/test-ui.sh` automatic device resolution can clone a template, but its helper shuts down the selected source, so it does not meet the “do not operate template” constraint for this run.

For phone actual-map refresh, import only the four affected root IDs from this single xcresult, one invocation per ID:

```sh
python3 docs/design/phone-design-map/collect-real-captures.py ipad <xcresult> --refresh-screen T03
python3 docs/design/phone-design-map/collect-real-captures.py ipad <xcresult> --refresh-screen A01
python3 docs/design/phone-design-map/collect-real-captures.py ipad <xcresult> --refresh-screen H01
python3 docs/design/phone-design-map/collect-real-captures.py ipad <xcresult> --refresh-screen L01
```

That importer uses the result's accessibility hierarchy and updates the selected screen IDs. The full-redesign theme collector is separate: first dry-run `python3 docs/design/full-redesign-map/collect-theme-captures.py ipad <xcresult> --dry-run`; only if it reports the expected named screenshots should it be imported. Existing capture sets require `--replace-existing`; it replaces the imported theme capture set, so do not use a partial Water Lilies-only result to replace the eight-theme set.

## Watch Series 12 (46mm)

Selectors available in `WatchThemeMatrixUITests`:

```sh
DUNEWatchUITests/WatchThemeMatrixUITests/testWaterLiliesHomeAndExerciseList
DUNEWatchUITests/WatchThemeMatrixUITests/testWaterLiliesWorkoutTheme
```

The helper currently chooses by simulator name and OS, not source UDID. With the stated template the intended setting is `DUNE_WATCH_SIM_NAME='Apple Watch Series 12 (46mm)' DUNE_WATCH_SIM_OS=27.2`; however it prefers any exact name+OS candidate and then calls the worktree clone helper, which shuts down that source. Confirm the selected runtime/source and template shutdown state before invoking; do not run while another simulator test owns the runner.

```sh
DUNE_WATCH_SIM_NAME='Apple Watch Series 12 (46mm)' DUNE_WATCH_SIM_OS=27.2 DUNE_UI_TEST_WALL_TIMEOUT=1200 scripts/test-watch-ui.sh --no-regen --test-plan DUNEWatchUITests-Full --log-file .codex-checks/theme-overhaul/watch-water-lilies.log --only-testing DUNEWatchUITests/WatchThemeMatrixUITests/testWaterLiliesHomeAndExerciseList --only-testing DUNEWatchUITests/WatchThemeMatrixUITests/testWaterLiliesWorkoutTheme
```

The theme full-redesign Watch importer `docs/design/full-redesign-map/collect-watch-theme-captures.py <xcresult> --dry-run` requires exactly 24 attachments (8 themes × 3 scenes), and replacement requires the same 24 keys from the same Watch simulator. The focused Water Lilies tests are evidence for that theme only; retain their xcresult and do not feed them into the full-set importer. The phone actual-map collector has an existing Watch workout-state path, not a Water Lilies theme gallery importer.

## Vision

Vision theme preference is intentionally per-app; do not expect App Group/iOS theme synchronization. Native runtime UI evidence is unavailable on this host per current inventory (visionOS SDK 27.2 installed, no runtime). When a compile check is useful, this is the generic native Vision build entrypoint:

```sh
DAILVE_FAST_LOCAL_BUILD=1 scripts/build-target.sh --scheme DUNEVision --platform visionos --build --no-regen --log-file .codex-checks/theme-overhaul/vision-build.log
```

This establishes compile evidence only, not a rendered Vision screen. No Vision screenshot/import should be claimed without an available runtime and new native capture.

## Evidence boundaries

- Keep each `.xcresult` as the source evidence. The full-redesign map importer consumes names from XCTest attachments; the phone actual-map importer consumes AX hierarchy and screen IDs. They are different imports, not image-copy destinations.
- `docs/design/full-redesign-map/collect-watch-theme-captures.py` only accepts the complete 24-screen matrix; partial Water Lilies evidence must remain separately identified.
- Current clone registry: phone clones only; no iPad or Watch clone is currently registered. Parent owns provisioning and execution.
