# iPad mini native visual review — 2c8b55481

Scope: read-only inspection of the staged iPad mini (A20 Pro, iOS 27.2) 1512 × 2316 px / 756 × 1158 pt portrait PNGs and paired AX, plus selected Water Lilies MAX and flow attachments in `exports/ipad-native/manifest.json`. `stage-ipad/provenance.json` ties staged roots to source `2c8b55481214c5eda0375815d930cb84b1c2db35`. The parent reports 10/10 scoped UI methods passed; visual conclusions below come from the PNGs.

## Findings

No concrete P1/P2/P3 visual defect in the inspected first viewports.

## Direct evidence

- `stage-ipad/images/water-lilies/{light,dark}/T03.png`, `forest/light/T03.png`, and `arctic/dark/T03.png`: the wide hero retains a visible trend line, readable time range, score, and delta chips. The pond, forest ridge, and aurora patterns fill the wider Canvas without covering title, status bar, toolbar, or hero text. The corresponding `stage-ipad/ax/.../T03.txt` files contain the root hero and hourly chart with data.
- `stage-ipad/images/water-lilies/light/H01.png` and `dark/L01.png`: Wellness uses a two-column evidence layout with readable scores/bars; Life's habits card, filters, and action cards fit the 756 pt viewport. No clipped glyph or horizontal overflow is apparent in the sampled viewports.
- Water Lilies MAX attachments `exports/ipad-native/35FE0B70-4D38-4B12-9E3C-275EC711DCDD.png` (Today), `63DB4C54-3564-4CDE-8BEF-A8B8EBA46BB4.png` (Wellness), `DA971CBF-BED3-4430-82C7-BC1894B27FD3.png` (Life), and `96C5F56B-9C31-4069-87C2-368D140B2780.png` (Activity): large text grows vertically and remains within card bounds; chart time range and Life filters/history action are visible. Content below the viewport continues by scrolling. The MAX Life water controls stack vertically, as expected at this text size.
- Water Lilies flow attachments `exports/ipad-native/725FC438-72AA-4967-BCB1-2B06B0FB59BA.png` (Light Condition Detail), `43C27B8A-96B4-4E51-8FD3-F87BA01A80E4.png` (Dark Compare Sheet), and `CB8E19A3-5AAE-4700-8CDD-0C66B4E76B7E.png` (Dark Quick Start Workout): titles, primary controls, and chart/list content are readable; the pond pattern sits behind the presented content without obscuring controls.

## Coverage limit

This is a visual sample of iPad mini portrait first viewports, not a whole-scroll audit or a claim about iPad Pro, landscape, all themes' flow screens, spoken VoiceOver output, or motion. The 756 pt viewport is materially narrower than the older 1032 pt iPad Pro reference; the inspection uses the actual staged mini dimensions.
