# Normal-launch WatchConnectivity readback plan — not executed

Status: source/help research only, 2026-11-14. No launch, attach, simulator mutation, build, or test performed. LLDB expressions and Simulator transport remain unverified at runtime. Respect one worktree runtime operation at a time; wait for the parent's active iPad run to end. No new execution budget is created by this research.

## Ownership and clean-state preconditions

- Registry currently identifies own phone `9D0602F1-9D0B-4AB0-B144-666748CCDC19`. Recheck registry plus actual device identity immediately before use. No Watch clone is registered at research time; future Watch UDID must be recorded and independently matched before pairing. Never choose `booted`, process name alone, or an existing unrelated pair.
- Preserve all capture/xcresult/log evidence first. If cloned accounts/data are present or unknown, use the parent's authorized erase/reinstall of only these verified own clones, then verify no signed-in account. Reinstall alone does not clear Simulator account/KVS state. Pair only the two owned IDs. Do not modify account credentials, entitlements, security settings, or debugger authorization.
- Keep existing installed debug artifact/signature or reinstall the previously built debug artifact; no rebuild is needed merely for readback. Capture artifact provenance and both app PIDs from explicit-device `simctl launch` output. Validate each host PID's executable path belongs to that exact owned device's app container; reject PID reuse or a different binary.
- Normal iPhone bundle: `com.raftel.dailve`. Normal Watch bundle: `com.raftel.dailve.watchkitapp` (`DUNE/project.yml:141,231,245`).

## Correct startup inputs and limitations

Phone command, after validating the prerequisites and with no runner active:

```sh
xcrun simctl launch --terminate-running-process \
  9D0602F1-9D0B-4AB0-B144-666748CCDC19 com.raftel.dailve \
  -com.dune.app.theme waterLilies \
  -hasShownCloudSyncConsent YES \
  -isCloudSyncEnabled NO
```

Launch the verified own Watch normally, with no theme injection:

```sh
xcrun simctl launch --terminate-running-process \
  "$DUNE_OWN_WATCH_UDID" com.raftel.dailve.watchkitapp
```

Run from a clean launcher environment: no `SIMCTL_CHILD_XCTestConfigurationFilePath`, injected XCTest libraries, or other inherited test environment; no `--uitesting`, `--healthkit-permission-uitest`, `--uitesting-watch`, seed, reset, or UI fixture arguments. `--ui-test-theme` is deliberately inapplicable to a normal launch. UserDefaults argument-domain values are process-local overrides, not proof of persisted preference changes; confirm actual outgoing context rather than relying on arguments alone.

- Theme key is exactly `com.dune.app.theme`; canonical values include `waterLilies` and `forestGreen` (`DUNE/Domain/Models/AppTheme.swift:19`). App startup reads UserDefaults, and WC sender rereads that same key in `currentThemeRawValue` (`WatchSessionManager.swift:355`).
- `hasShownCloudSyncConsent=YES` makes the normal launch planner ready after splash; automatic What's New is disabled. `finishLaunchExperienceIfNeeded()` invokes `startRuntimeServicesIfNeeded()` synchronously, and WC activation occurs before scheduling deferred authorizations (`DUNEApp.swift:786–813`).
- **`-isCloudSyncEnabled NO` is insufficient to guarantee local-only operation on a cloned signed-in account.** `CloudSyncPreferenceStore.resolvedValue()` calls `NSUbiquitousKeyValueStore.synchronize()` and resolves `cloudValue ?? localValue ?? false`; cloud `true` wins. Its object-based Boolean parser may also ignore string-valued argument-domain `NO`. Safe precondition is a clean own no-account Simulator with absent/false cloud value and local false/absent preference. Absent values resolve false; Watch Simulator unconditionally disables CloudKit. Do not use debugger writes to alter KVS/account state.
- `hasRequestedHealthKitAuthorization=YES` does **not** suppress HK authorization: `revalidateEachLaunch: true`. There is no needed HK bypass for WC: activation starts first, then authorization waits 400ms. Leave real permission behavior intact. Normal startup can display an HK sheet; this is not proof of transport failure.
- The phone activates WC only outside test bypass. Watch `applyUITestFixturesIfNeeded()` returns before activation when `--uitesting-watch` is present. Existing UI fixture success cannot establish actual transport.

## Exact public getters and bounded LLDB invocation

The local SDK `WatchConnectivity.framework/Headers/WCSession.h` declares Objective-C `+[WCSession defaultSession]`, `applicationContext`, and `receivedApplicationContext`. Read activationState on both, then extract only the `appTheme` value from outgoing context on phone and incoming context on Watch. Never dump the full context (it can contain exercise/personal payloads). The SDK enum maps 0=notActivated, 1=inactive, 2=activated; require 2 for both endpoints. Do not call `activate`, `updateApplicationContext`, private selectors, app sync functions, or write defaults in the debugger.

Proposed commands for a debugger script, after attaching the verified PID:

```text
expression --language objc --timeout 2000000 --all-threads false --unwind-on-error true -- @import WatchConnectivity
expression --language objc --timeout 2000000 --all-threads false --unwind-on-error true -- (long)[[WCSession defaultSession] activationState]
expression --language objc --object-description --timeout 2000000 --all-threads false --unwind-on-error true -- (id)[[[WCSession defaultSession] applicationContext] objectForKey:@"appTheme"]
```

On Watch replace only the final expression's context getter with `receivedApplicationContext`. The `@import` and expressions must be checked at runtime; SDK existence is not proof LLDB can import that simulator module. If import fails, stop and record that exact error. A possible separate diagnosed alternative is `expression --language swift -- import WatchConnectivity` followed by `WCSession.default.receivedApplicationContext["appTheme"]`; do not silently retry an undiagnosed failure.

Use a small ignored LLDB Python driver with this structure, rather than separate `-o expression -o detach` commands that can abort before detaching:

```python
import lldb

def probe(debugger, pid, getter):
    assert isinstance(pid, int) and pid > 0
    assert getter in ("applicationContext", "receivedApplicationContext")
    interpreter = debugger.GetCommandInterpreter()
    debugger.SetAsync(False)
    def checked(command):
        result = lldb.SBCommandReturnObject()
        interpreter.HandleCommand(command, result)
        print(result.GetOutput() or "", flush=True)
        if not result.Succeeded():
            raise RuntimeError(result.GetError() or command)
    try:
        checked(f"process attach --pid {pid}")
        checked("expression --language objc --timeout 2000000 --all-threads false --unwind-on-error true -- @import WatchConnectivity")
        checked("expression --language objc --timeout 2000000 --all-threads false --unwind-on-error true -- (long)[[WCSession defaultSession] activationState]")
        checked('expression --language objc --object-description --timeout 2000000 --all-threads false --unwind-on-error true -- (id)[[[WCSession defaultSession] ' + getter + '] objectForKey:@"appTheme"]')
    finally:
        process = debugger.GetSelectedTarget().GetProcess()
        if process.IsValid() and process.GetProcessID() == pid:
            state = process.GetState()
            if state not in (lldb.eStateDetached, lldb.eStateExited, lldb.eStateInvalid):
                detached = process.Detach(False)
                print("DETACH_SUCCESS=" + str(detached.Success()), flush=True)
                if detached.Fail():
                    raise RuntimeError("Detach failed: " + str(detached))
```

Save that future helper as `.codex-checks/theme-overhaul/lldb_watch_probe.py`. For a verified numeric PID `12345`, exact command shape is:

```sh
python3 scripts/lib/command-deadline.py --seconds 45 -- \
  xcrun lldb --no-lldbinit --batch \
  -o 'command script import .codex-checks/theme-overhaul/lldb_watch_probe.py' \
  -o 'script lldb_watch_probe.probe(lldb.debugger, 12345, "applicationContext")'
```

Use the actual own Watch PID and `"receivedApplicationContext"` for Watch. Execute sequentially. Neither `--wait-for` nor process-name attach is acceptable. The helper is a plan, not an already validated artifact; Python scripting can print an exception without a trustworthy nonzero LLDB exit, so the caller must require successful attach, getter output, and explicit `DETACH_SUCCESS=True`. Any traceback/error, missing marker, or outer timeout is failure regardless of CLI exit code.

`finally` detaches after ordinary attach/expression exceptions and successful getter reads. `Detach(False)` requests resume, matching `process detach --keep-stopped false`. The SDK help confirms these public LLDB APIs. **A forced watchdog SIGKILL cannot run Python finally; absolute detach after hard timeout cannot be guaranteed by this script.** The repository deadline wrapper TERM/KILLs its owned command group. After timeout/abnormal termination, stop readback and inspect the verified app PID's tracing/stopped state before any continuation; missing detach evidence remains a cleanup failure. Do not claim guaranteed detach or successful proof, do not terminate unrelated processes, and do not launch a duplicate attach. A future robust controller must handle orderly interruption/detach before its hard kill; that implementation is not covered by this read-only plan.

If macOS denies attach or requests debugger authorization, record the exact diagnostic as blocked. Do not use sudo, `DevToolsSecurity`, entitlement/resigning changes, task-port workarounds, or authentication bypass.

## Evidence sequence and interpretation

1. Launch clean own pair normally with phone `waterLilies`; allow bounded normal delivery time without a debugger attached. Attach phone once, read activation state and only outgoing appTheme, detach; then attach Watch once, read activation state and only received appTheme, detach. Preserve raw output, app/SDK build identifiers, pair IDs, PIDs, timestamps, and detach markers.
2. With both detached, relaunch only phone normally with `-com.dune.app.theme forestGreen` and the same consent/local-only preconditions. Keep Watch free of theme arguments and debugger writes. Obtain a second sequential outgoing/received pair after bounded normal delivery time.
3. Required transport evidence: outgoing phone `appTheme=waterLilies` then Watch **received** `appTheme=waterLilies`, followed by outgoing `forestGreen` then Watch **received** `forestGreen`. A single matching cached value is weaker; the changed second value excludes stale first-state evidence. Watch readback establishes WC receipt, not by itself UI consumption/rendering. Capture normal Watch UI after detachment if actual rendering evidence is required and authorized.
4. Empty/stale context, expression/import/attach failure, missing detach confirmation, runtime pairing unsupported, or deadline => record the exact gap. No context write, test-fixture fallback, simulated delivery, or source-only reasoning counts as actual transport proof. WC context delivery is asynchronous; SDK says delivery occurs at system-chosen appropriate time, potentially after sender exits, so no immediate delivery guarantee.

## Prior art and confidence

- `docs/solutions/architecture/2026-03-11-launch-permission-deferral-stability.md`: launch readiness before deferred HK/notifications.
- `docs/solutions/general/2026-03-03-watch-simulator-cloudkit-noaccount-fallback.md`: Watch Simulator CloudKit disabled and test fixture activation bypass.
- `docs/solutions/general/2026-03-12-watch-reinstall-library-rehydrate.md`: activation rehydrates context from persistent phone sources.
- `docs/solutions/design/2026-03-01-multi-theme-architecture.md`: theme transport and Watch consumption architecture.

High confidence: repository keys, startup order, fixture bypass, cloud precedence, public SDK property selectors, local LLDB help flags. Unverified: Simulator pair transport in this runtime, normal-launch argument-domain interpretation in this installed artifact, entitlement/host attach authorization, Objective-C module import/JIT getter evaluation, and hard-timeout detach behavior. This document is a proposed bounded observation method, not a passed transport check.
