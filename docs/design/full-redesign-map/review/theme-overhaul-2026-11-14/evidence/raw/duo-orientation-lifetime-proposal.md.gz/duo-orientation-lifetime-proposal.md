# Duo Open orientation: read-only diagnosis and proposed adapter delta

Status: PROPOSED ONLY. Current adapter/source untouched. No helper, device query, orientation setter, build, test, or normal app launch executed by this investigation. Only local files/git objects and `devicectl ... set --help` read. Original failure and one conditional retry budget remain intact.

## Finding

The adapter violates the pinned helper's persistent command/reply lifetime contract:

- `.codex-checks/theme-overhaul/duo-orientation-driver.py:20` uses `subprocess.run(input=...)`, which closes stdin after its single line.
- Pinned `SimDuoHID/main.m:100,129,132` reads until EOF; `OK` acknowledges `dispatchEvent:` only, then EOF immediately invokes `cancel` on the HID services. There is no delivery wait/barrier after dispatch.
- Same pinned commit's `packages/serve-sim/Sources/SimNative/DuoHIDBridge.swift` retains Process/input/output properties; `send()` writes one line, reads OK with a 3-second deadline, and returns without closing stdin. `stop()` closes/terminates only when shutting down/failing. This is direct evidence of intended lifetime, not inference from a comment.
- Same pinned commit's `.agents/skills/serve-sim-duo-verification/scripts/verify-duo-rotation.ts` waits 1200ms after orientation and explicitly documents asynchronous guest rotation. It validates official physical readback before accepting the change.
- The separate successful hinge helper explicitly sleeps 100ms before exiting “Give the event system a moment to deliver”; it also uses a different IOHIDEventSystemClient transport, so hinge success does not validate short-lived HIDVirtualEventService delivery.

Strong hypothesis: one-shot EOF cancels the service before orientation is consumed, or lifetime must extend through consumer processing. This is NOT yet a proven root cause on SDK 27.2. Holding the helper through readback is a concrete source-supported change worthy of the existing one conditional retry; it is not a reason to allocate another retry afterward.

## Existing evidence and limits

Failure directory: `duo-theme-open-DesertWarm-OceanCool-ForestGreen-SakuraCalm-20261114T125152Z`.

- SDK 27.2, pinned c60d583747b88a15616eeecec56f287ef5759769; recorded adapter SHA fdd1242e18cf870ac8c2d1790231e1516de297fad28009d7fa31e6e463a40d9e.
- Hinge setter exit succeeded. Official displays after: LCD inactive/off; LCD-1 active/activeOn, nativeSize 2007x2853, currentOrientation rot0. Thus inner-panel activation occurred.
- Official orientation after: portrait/nonFlat portrait, orientationLocked false. This contradicts required physical landscapeLeft before any UI test; no app-layout failure was exercised.
- `.codex-checks/b05/duo-open-readiness-cause.md` describes prior SDK27.2 physical portrait with inner currentOrientation rot90 on a DIFFERENT old owned UDID. It is not proof this adapter worked, nor evidence to weaken today's landscapeLeft gate.
- 2026-10-06 source-pinned probe records portrait→landscapeLeft→portrait on SDK27.1 and another UDID. Its JSON does not preserve subprocess lifetime. The solution text says OK plus process exit checked; do not claim that earlier local wrapper was persistent. Only the upstream bridge is demonstrably persistent.
- Local SDK27.2 help still offers official `devicectl device orientation set --device UUID landscapeLeft`, explicitly “if supported.” Prior SDK27.1 official-set success/readback-portrait is preserved in docs. Help availability alone does not establish changed support; do not consume the retry by cycling through another setter.

## Minimal adapter proposal (not applied)

Keep DEVICE, TOKENS, pinned binary validation and single orientation command unchanged. Replace `subprocess.run(input=...)` with a retained `Popen` session:

1. Launch the same exact `xcrun simctl spawn DEVICE binary` once with stdin/stdout PIPE, stderr in a task-owned temporary file (avoids pipe backpressure); no shared/global process operations.
2. Write and flush exactly one `orientation 3\n` (or existing requested token); do not close stdin.
3. Read one newline-terminated ACK with `selectors`/`os.read`, at most 64 bytes and a 3-second monotonic deadline, matching upstream. Reject anything except exact `OK`; reject helper exit. Do not call blocking `readline()` after mere readiness because a partial line could hang.
4. Keep stdin open for 1.2 seconds after ACK, matching the upstream verifier's documented consumer interval. This pause is backed by the upstream asynchronous contract; it is not itself success evidence.
5. With helper still alive, issue EXACTLY ONE official readback:

   `xcrun devicectl device orientation get --device D1E42917-AF53-4D67-A382-CB6B87FC5A1D --timeout 10 --quiet --json-output -`

   Give subprocess 12 seconds total. Save its unmodified stdout/stderr and target/ACK/timestamps to a uniquely named receipt beside this run's binary. Require command success, `info.outcome == success`, exact matching `result.deviceIdentifier`, `deviceOrientation == requested`, `deviceOrientationNonFlat == requested`, `deviceIsOrientationLocked == false`, and helper still alive. One readback only; do not send another orientation command or alternate enum on failure.
6. In `finally` on success, failure, KeyboardInterrupt, and handled SIGTERM: close the helper stdin to request EOF/cancel; wait up to 2s for that owned Popen; if still alive, terminate ONLY that owned Popen and wait 1s, then kill ONLY it and wait 1s. Close stdout/tempfile and restore any scoped signal handler. Record exit/termination mode; normal cleanup requires exit0. Do not print OK until cleanup completes. No killall/pkill/global CoreSimulator service changes.
7. This retained session fits current 30s caller budget: ACK3 + pause1.2 + readback12 + cleanup4 ≈20.2 seconds. Keep the existing outer runner deadline and lock. Do not create a detached session that evades the outer watchdog.

Implementation cleanup caveat: `simctl spawn` is a host wrapper; its successful normal exit after stdin EOF is the expected clean guest shutdown path. If escalation is needed, merely killing host `simctl` cannot be claimed to prove guest termination. Mark cleanup failed and inspect exact executable-path/own-device process metadata before any later work. Only terminate a guest PID if ownership is independently established by that unique binary path and device; never guess by shared process name. A hard SIGKILL cannot run Python finally. Missing cleanup evidence blocks continuation.

This is a lifetime-and-readback delta only. Do not rebuild/change pinned main.m, alter provider/source/enum payload, switch to an official setter in the same attempt, change app/tests, or relax expected orientation.

## Readback and final acceptance

- The retained helper's live readback is necessary, not sufficient. The existing batch's independent after-readback runs AFTER helper closure; keep it. Require exact landscapeLeft/nonFlat landscapeLeft again. This detects orientation that only exists while helper is alive.
- Existing displays gate remains: LCD-1 active and activeOn; LCD inactive. Numeric hinge angle remains unmeasured/null under current devicectl; do not label 180° measured merely from setter intent.
- Only after BOTH orientation receipts and display gate pass may the existing UI batch run, under its already held conditional retry. Fresh XCTest viewport and paired native PNG remain mandatory. Physical direction, panel native dimensions, app interface orientation and PNG dimensions are separate facts: prior inner physical portrait had landscape app viewport, so don't infer app aspect solely from physical getter.
- On mismatch/error/timeout/cleanup failure: retain raw evidence, stop before UI, no ACK, no second orientation setter, no orientation fallback and no new retry budget. Report Open coverage still blocked; Closed source861 results remain valid within their scope.

Coverage: critical gap for planned Open posture until actual readback+UI evidence. No new app/UI testcase required to diagnose this preflight. iPad is unaffected and must not be operated by this work.
